package practice;

    class Employee{
        int id;
        int salary;
        String name;
        public void printDetails(){
            System.out.println("My id is " + id);
            System.out.println("and my name is "+ name);
//            System.out.println(salary);

        }
        public int getSalary(){
            return salary;
        }
    }
public class Y_15_FirstCustomClass {
        public static void main(String[] args) {
            System.out.println("This is our custom class");
            Employee manish = new Employee(); // Instantiating a new Employee Object
            Employee john = new Employee(); // Instantiating a new Employee Object

            // Setting Attributes for Harry
            manish.id = 12;
            manish.salary = 34;
            manish.name = "Manish Shah";

            // Setting Attributes for John
            john.id = 17;
            john.salary = 123;
            john.name = "John Khandelwal";

            // Printing the Attributes
            manish.printDetails();
            john.printDetails();
            int sal = john.getSalary();
            System.out.println(sal);
            // System.out.println(harry.id);
            // System.out.println(harry.name);
        }
    }

