package practice;

import java.util.Scanner;

public class Factorial
{
     public static void main(String[] args){
          int fact=1;
          System.out.println("enter the number to find factorial of:");
          Scanner s=new Scanner(System.in);
          int a=s.nextInt();
          while(a>0)
          {
               fact=fact*a;
          a--;

     }
          System.out.println("factorial is "+ fact);


     }

}
