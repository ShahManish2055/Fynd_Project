package practice;

public class ForEach {
    public static void main(String[] args) {
//        int i, j;
        int [] arr={2,32,1,43,12,322};
        String [] name={"manish","ram","hari","andrin"};
        System.out.println("length of array is:"+arr.length);
        for(int manish:arr){
            System.out.println(manish);
        }
        for(String shah:name)
        {
            System.out.println(shah);
        }
//        for (i = 0; i < 6; i++) {
////            System.out.println(marks[i]);
//            for (j = 0; j < i; j++) {
//                System.out.print("*");
//                System.out.print("\t");
//            }
//            System.out.println();
//        }
//            for (i = 5; i >=0; i--) {
////            System.out.println(marks[i]);
//                for (j = 0; j<=i; j++) {
//                    System.out.print("*");
//                    System.out.print("\t");
//                }
//                System.out.println();
//            }
        }
    }

