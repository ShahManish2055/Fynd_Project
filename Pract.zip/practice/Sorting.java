package practice;
import java.util.*;
public class Sorting {
    static void result(int[] arr,int n){
        System.out.print("Bubble sorted values are:");
        for(int i=0;i<n;i++){
            System.out.print( arr[i]+" ");
        }
    }
    public static void main(String[] args) {
        Scanner a=new Scanner((System.in));
        int[] arr= new int[10];
        System.out.print("enter the number of array you want:");
        int n=a.nextInt();
        for(int i=0;i<n;i++) {
            int ay = a.nextInt();
            arr[i]=ay;
        }
        System.out.print("unsorted values are:");
        for(int i=0;i<n;i++) {
            System.out.print(arr[i]+" ");
        }
        for(int i=0;i<n-1;i++){
            for(int j=0;j<n-i-1;j++){
                if(arr[j]>arr[j+1]){
                    int b=arr[j];
                     arr[j]=arr[j+1];
                     arr[j+1]=b;
                }
            }
        }
        System.out.println();
        result(arr,n);
        System.out.println();

//        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
//        System.out.print("selection sort values are:");
//        for(int i=0;i<n-1;i++){
//            int small=i;
//            for(int j=i+1;j<n;j++){
//                if(arr[small]>arr[j]){
//                    small=j;
//                }
//            }
//            int sel=arr[small];
//            arr[small]=arr[i];
//            arr[i]=sel;
//        }
//        for(int i=0;i<n;i++){
//            System.out.print(arr[i]+" ");
//        }



    }
}


