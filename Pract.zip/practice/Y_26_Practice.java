package practice;
class circle{
   int  radius;

       circle(int r){
           radius=r;
       }
    public double area(int t){
       return Math.PI*radius*t;

   }
}
class cylinder extends circle{

    public int height;
    public int radius;
//    int t;
    cylinder(int r, int h,int t){
        super(r);
        super.area(t);
        height=h;
      radius=r;
    }
    public double cylinder() {

        return Math.PI * radius * radius * height;
    }
}
public class Y_26_Practice {
    public static void main(String[] args) {
        cylinder c=new cylinder(4,5,8);
        System.out.println("cylinder area is:"+ c.cylinder());
        System.out.println("circle area is:"+c.area(8));


    }
}
