package practice;
//class GFG {
//
//    // Static block
//    static
//    {
//        // Print statement
//        System.out.print(
//                "Static block can be printed without main method");
//    }
//}
//class dog {
//
//        String s = "";
//        this.s="jjfd";
//        System.out.println(s);
//   // }
//}
////AB212CV35
public class Constructor {
    static
    {
        // Print statement
        System.out.print(
                "Static block can be printed without main method");
    }
    public static void main(String[] args) {

    }}
//        dog d=new dog();
//        d.s="rocky";
//        System.out.println(s);
//
////        String s="abc";
////        try {
////            int a = Integer.parseInt(s);
////        }
////        catch(Exception e){
////            System.out.println(e);
////        }
//
//
//    }
//}
//
//
