package practice;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
public class Y_55_DateTimeFormattter {
    public static void main(String[] args) {

                LocalDateTime dt = LocalDateTime.now(); // This is the date
                System.out.println(dt);

                DateTimeFormatter df = DateTimeFormatter.ofPattern("dd/MM/yyyy -- E H:m a Y"); // This is the format
                DateTimeFormatter df2 = DateTimeFormatter.ISO_LOCAL_DATE;

                String myDate = dt.format(df); // Creating date string using date and format
                System.out.println(myDate);
//------------------------------------------------------------------------------------
        DateTimeFormatter df1 = DateTimeFormatter.ISO_ORDINAL_DATE;//

        String my = dt.format(df1);
        System.out.println("Date in ISO_WEEK_DATE Format  : "+ my);


        DateTimeFormatter df3 = DateTimeFormatter.ISO_WEEK_DATE;//

        String myDat = dt.format(df3);
        System.out.println("Date in ISO_WEEK_DATE Format  : "+ myDat);

            }

}
