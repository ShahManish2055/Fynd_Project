package practice;
import practice.Y_17_AccessModifier;
    class C2{
        public int x = 5;
        protected int y =45;
        int z = 6;
        private int a = 78;
        public void meth1(){
            System.out.println(x);
            System.out.println(y);
            System.out.println(z);
            System.out.println(a);
        }
//        class cr extends Y_17_AccessModifier;
//        Y_17_AccessModifier v=new Y_17_AccessModifier();
//            System.out.println(v.w);

    }
public class Y_32_Access_Modifier {
        public static void main(String[] args) {
            C2 c = new C2();
             c.meth1();
//            System.out.println(c.a);//it is not possible coz a is a private access modifier

            System.out.println(c.x);//these are possible
            System.out.println(c.y);
            System.out.println(c.z);
            // System.out.println(c.a);
        }
    }


