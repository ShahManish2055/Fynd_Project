package practice;
//The StringBuffer and StringBuilder classes are used when there is a necessity to make a lot of modifications to Strings of characters.
//
//        Unlike Strings, objects of type StringBuffer and String builder can be modified over and over again without leaving behind a lot of new unused objects.
import java.lang.reflect.Type;
import java.util.Arrays;
public class StringMethod {
    public static void main(String[] args) {
        String name="Manish";
     System.out.println(Character.isUpperCase(name.charAt(1)));
//        String v="Manish";
//     v =v+"man";
//     System.out.println(v);
        String cast="shah";
       System.out.println(name.length()+cast.length());
        StringBuffer str= new StringBuffer("hello");
        System.out.println(str.append("world"));
        System.out.println(str);
        System.out.println(str.reverse());
        StringBuilder sb=new StringBuilder("call");
        System.out.println("sd");
        System.out.println(sb.append("me"));
        char w[]={'m','a','n','i','s','h'}; //these are the  way to write the string.
        String s =new String("shah");
        String t =new String(s);
        System.out.println(name.compareTo(t));//'if name values is greater then it return positive value else negative value

        int length=name.length();
        System.out.println(length);
        System.out.println(w);
        System.out.println(s);
        System.out.println(t);

        String lower=name.toLowerCase();
        System.out.println(lower);
        String upper=name.toUpperCase();
        System.out.println(upper);

        System.out.println(name.substring(3));
        System.out.println(name.substring(4));
        System.out.println(name.substring(0,4));
        System.out.println(name.replace('M' , 'A'));
        System.out.println(name.replace("ish","um"));
        System.out.println(name.startsWith("Man"));
        System.out.println(name.startsWith("ani"));
        System.out.println(name.endsWith("man"));
        System.out.println(name.equals("Manish"));//equal with my name
        System.out.println(name.equalsIgnoreCase("maNisH"));//it is equal weather it would be upper case or lower case
        System.out.println(name.charAt(2));
        System.out.println(name.indexOf("is"));
        System.out.println(name.indexOf("is8975"));
        System.out.println(name.lastIndexOf("h"));

        String value="manishanish";
        System.out.println(value.lastIndexOf("ni",5));
        System.out.println(value.lastIndexOf("ni",8));


        String lastname="   shah   ";
        System.out.println(lastname);

        System.out.println(lastname.trim());// it remove space of string

        System.out.println("\"i m doing java\" and seems leangthy");
        System.out.println("i m doing java\\ and seems leangthy");
        System.out.println("i m doing java \n seems leangthy");
        System.out.println("i m doing java \t \t and seems leangthy");

                String myString[]={"M","A","N","I","S","H"};
                Arrays.sort(myString);
                System.out.println(Arrays.toString(myString));
        String Array[]={"Apple","Aat","Ear","Ball","Dog"};
        Arrays.sort(Array);
        System.out.println(Arrays.toString(Array));

            }
        }

