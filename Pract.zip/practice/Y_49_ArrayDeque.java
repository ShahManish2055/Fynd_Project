package practice;
import java.util.ArrayDeque;
public class Y_49_ArrayDeque {
            public static void main(String[] args) {
                ArrayDeque<Integer> ad1 = new ArrayDeque<>();
                ad1.add(6);
                ad1.add(56);
                ad1.add(9);
                ad1.addFirst(5);
                System.out.println(ad1);
//                ad1.pollFirst(); //deletes 5
//                ad1.removeFirst(); //deletes 6
               ad1.pollLast(); //deletes 9
                ad1.removeLast(); //deletes 56
                System.out.println(ad1);
                System.out.println(ad1.getFirst());
                System.out.println(ad1.getLast());
                System.out.println(ad1.peekFirst());
                System.out.println(ad1.peekLast());


            }
        }


