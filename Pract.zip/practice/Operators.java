package practice;

public class Operators {
    public static void main(String[] args) {
//        Arithmetic operator(+,-,*,/,%,++,----)
//        assignment operator
        int a=4;
        int b=9-a;
        b+=10;
        System.out.println(b);
        System.out.println(7==9);//comparison operator
        //logical operator
        System.out.println(7<8 && 9>8);
        System.out.println(87>76||66>76);
//        bitwise operator
        System.out.println(2&3);//it convert 2 and 3 into binary and do Anding on it.


    }
}
