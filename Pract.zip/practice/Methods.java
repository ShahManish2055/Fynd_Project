package practice;

public class Methods {
    static void mark(int[] arr){
        arr[0]=80;

//        if(arr[0]==9){
//            System.out.println(true);
//        }
//        else{
//            System.out.println(false);
//        }
    }
    int logic(int x, int y){
            int z;
            if(x>y){
                z = x+y;
            }
            else {
                z = (x +y) * 5;
            }
            x = 566;
            return z;
        }


        public static void main(String[] args) {
            int a = 5;
            int b = 7;
            int c;
//             Method invocation using Object creation......mean that non-static members can't be call from static method
             Methods obj = new Methods();
            c = obj.logic(a, b);
//            c = logic(a, b);
            System.out.println(a + " "+ b);
            int a1 = 2;
            int b1 = 1;
            int c1;
            c1 = obj.logic(a1, b1);
//            c1=logic(a1,b1);
            int [] arr={ 7,9,45,76,4,9};
            mark(arr);
            System.out.println(c);
            System.out.println(c1);
            System.out.println("marks is:"+ arr[0]);
        }
    }
