package practice;

import java.util.ArrayList;
import java.util.Collections;

public class Y_47_Collection_Framework_Arraylist {
    public static void main(String [] arg){
//       List a=new ArrayList();  // this does not allow Type safety so because of that we use <Integer> for type safety.
//        a.add(2);
//        a.add("this does not provide type safety");
//        System.out.println(a.get(0).getClass().getName());
//        System.out.println(a.get(1).getClass().getName());

        ArrayList<Integer> m1= new ArrayList<>();  //here m1 is like a name of array in array list.
        ArrayList<Integer>m2=new ArrayList<>(); // actually we don't put integer inside arrow head coz we have already
        m1.add(9);                                //       mention it  but it doesnot effect though we put into arrow head.
        m1.add(3);
        m1.add(7);
        m1.add(0,1);
        m1.add(2);
        m2.add(44);
        m2.add(2);
        m2.add(1);
        m1.addAll(3,m2);  //it put all the  m2 values into m1 from index 3 .
        System.out.println(m1.contains(2));
        System.out.println(m1.indexOf(44));
        System.out.println(m1.lastIndexOf(2));
        m1.set(1, 566); //it replace the index1 elements from the arraylist.
        Collections.sort(m1);
        System.out.println(m1.subList(0,6));  //it shows array from the given limits.
//        m1.clear();
//        m1.remove(0);
        System.out.println(m1.isEmpty()); //if there is no array list then it show true but here we have array list so it is showing false.
//        System.out.println(m1); //even this work to print the whole value in arraylist instead for loop.
        for(int i=0;i<m1.size();i++){
            System.out.print(m1.get(i)+",");
//            System.out.println(m1.get(i));
        }
//
    }
}
