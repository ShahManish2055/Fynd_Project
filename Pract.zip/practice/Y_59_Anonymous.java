package practice;
//The Anonymous class in Java can be created by two ways :
//
//By extending a class
//By implementing an interface

//*By extending a class
abstract class Vehicle{
    abstract void drive();
}
//-----------------------------------------------------------------
//*By implementing an interface
@FunctionalInterface
interface Human{
    void walk();
}
//-----------------------------------------------------------------
//Lambda Expression
@FunctionalInterface
interface LamdaExp{
    void meth1(int a, int b);
}
//-----------------------------------------------------------------
   public class Y_59_Anonymous {
    public static void main(String[] args) {

//        Anonymous class
        Vehicle car = new Vehicle() {
            @Override
            void drive() {
                System.out.println("I'm driving a car.");
            }
        };

        car.drive();
        // -----------------------------------------------------------------
                Human John = new Human() {
                    @Override
                    public void walk() {
                        System.out.println("John walks.");
                    }
                };
                John.walk();
//                ---------------------------------------------------
//Lambda Expression * note it only work in functional interface(only one method decleration)
                LamdaExp obj =(a,b)->{
                    System.out.println("The value of a and b is : "+ a + "," + b);
                };
                obj.meth1(5,10);
            }
        }



