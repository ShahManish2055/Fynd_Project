package practice;
import java.time.*;

public class Y_54_Time_Api {
            public static void main(String[] args) {
                LocalDate d = LocalDate.now();
                System.out.println(d);
                LocalTime t = LocalTime.now();
                System.out.println(t);
                LocalDateTime dt = LocalDateTime.now();
                System.out.println(dt);
                LocalDate w1 = LocalDate.parse("2021-05-27");
                LocalDate w2= LocalDate.parse("2021-05-26");
                LocalDate w3= LocalDate.parse("2021-05-26");

                System.out.println(w2.equals(w1));
                System.out.println(w3.equals(w2));

                LocalDate z = LocalDate.parse("2021-05-27");
                System.out.println(z.withYear(2001));
                System.out.println();

                LocalTime u = LocalTime.of(13,18,29);
                System.out.println("Time before : "  + u);
                LocalTime t1= u.plusHours(5);

                System.out.println();

                System.out.println("Time after adding 5 hours : " + t1);
                System.out.println();
                LocalTime w = LocalTime.of(15,28,19);
                System.out.println("Time before : "  + w);

                LocalTime t2= w.minusMinutes(8);
                System.out.println("Time after subtracting 8 minutes : " + t2);

                Duration p1 = Duration.between(LocalTime.MIN,LocalTime.NOON);  //LocalTime.MIN = '00:00' , LocalTime.NOON = '12:00'
                System.out.println(p1.isNegative());

                Duration p2 = Duration.between(LocalTime.MAX,LocalTime.MIN);  //LocalTime.MAX =  '23:59:59.999999999' ,  LocalTime.MIN = '00:00'

                System.out.println(p2.isNegative());

                Clock l = Clock.systemDefaultZone();
                System.out.println(l.getZone());
            }
        }

