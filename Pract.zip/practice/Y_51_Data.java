package practice;

import java.sql.Time;
import java.util.Date;


public class Y_51_Data {
    public static void main(String[] args) {

        System.out.println(Long.MAX_VALUE); //it is safe to store millisecond in long type.
        System.out.println(System.currentTimeMillis());
                System.out.println(System.currentTimeMillis()/1000/3600/24/365);

             Date  m= new Date();
        System.out.println(m);
        System.out.println(m.getTime()); // it give time in millisecond like above.
        System.out.println(m.getDate());
        System.out.println(m.getSeconds()); //note:this cut line means these method are deprecated or can say changed.
        System.out.println(m.getYear()); //it give passed year from the 1990
            }
        }
