package practice;

import java.util.Date;

public class Manish {
    public static void main(String[] args) {
        Date time= new Date();
        System.out.println(time);


    }
}
