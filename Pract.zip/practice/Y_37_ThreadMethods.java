package practice;
//sleep and join method.

class met1 extends Thread{
    public void run() {
        int i=0;
        while ( i<10) {
            System.out.println("i m busy");
            i++;
        }
    }
}
class met2 extends Thread {
    public void run() {
        try {
            int i = 0;
            while (i < 10) {
                System.out.println("i m not busy");
                i++;
                Thread.sleep(500);
            }
        }
            catch(InterruptedException t){
                System.out.println("Exit interrupt");
                System.out.println(t);
            }
        }
    }
public class Y_37_ThreadMethods {
    public static void main(String[] args) {
        met1 m = new met1();
        met2 a = new met2();
        m.start();
        try {
            m.join(); // join method intend to finish one statement of programe i.e first finish m.start and after accomplishment other instently initiate.
        } catch (Exception i) {
            System.out.println("interrupt end");
            System.out.println(i);
        }

        a.start();
//        a.interrupt(); // this interrupt allows  to execute  a.start only once.
    }
}


//....................................................................................
//
//class met1 extends Thread{
//    public void run() {
//        int i=0;
//        while ( i<100) {
//            System.out.println("i m busy");
//            i++;
//        }
//    }
//}
//class met2 extends Thread {
//    public void run() {
//        int i=0;
//        while (i<100) {
//            System.out.println("i m not busy");
//            i++;
//        }
//    }
//}
//public class Y_37_ThreadMethods {
//    public static void main(String[] args) {
//        met1 m = new met1();
//        met2 a = new met2();
//        m.start();
//        try {
//            m.sleep(3000); // join method intend to finish one statement of programe i.e first finish m.start and after accomplishment other instently initiate.
//        } catch (InterruptedException i) {
//            System.out.println("interrupt end");
//        }
//
//        a.start();
//    }
//}


//-----------------------------------------------------------------------------------------------------------
//class CWH1 extends Thread{
//    public void run(){
//        for (int i=0;i<10;++i){
//            System.out.println(i);
//        }
//    }
//}
//
//public class Y_37_ThreadMethods extends Thread{
//    public static void main(String[] args) {
//        CWH1 t= new CWH1();
//        t.start();
//        t.interrupt(); // no use of interrupt if there is not any waiting state like sleep ,join.
//        System.out.println("Main Thread");
//
//    }
//}
//................................

//yield method= it stop itself and allow other thread to execute first and later it start .
// note:sometime Thread scheduler ignore yield method and execute programe normally.
//
//class CWH1 extends Thread{
//    public void run(){
//        for (int i=0;i<10;++i){
//            System.out.println(i);
//            Thread.yield();
//        }
//    }
//}
//class CWH2 extends Thread{
//    public void run(){
//        for (int i=0;i<10;++i){
//            System.out.println("hyee");
//        }
//    }
//}
//public class Y_37_ThreadMethods extends Thread{
//    public static void main(String[] args) {
//        CWH1 t= new CWH1();
//        CWH2 t2= new CWH2();
//        t.start();
//        t2.start();
//    }
//}
