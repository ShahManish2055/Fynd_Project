package practice;
interface interr{
    void run();
    private void code() {
        System.out.println("i m private methode 1");
    }
    default void shah(){
        code();
        System.out.println("i m  default method");
    }

}
interface face extends interr{
    void manish();

}
class done implements face{
    public void run(){
        System.out.println("i m run method in interface");
    }
    private void name(){
        System.out.println("i m private method 2");
    }
   public void walk(){
        System.out.println("i m walk method in interface");
    }
   public void manish(){
        System.out.println("i m manish method in interface");
        name();
    }
}

public class Y_30_Interface_inheritance {
    public static void main(String[] args) {

        done d = new done();
        d.run();
        d.walk();
        d.manish();
        d.shah();

    }
}
