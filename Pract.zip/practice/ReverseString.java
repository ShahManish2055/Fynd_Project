package practice;

import java.util.Scanner;

public class ReverseString {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter String: ");
        String s = sc.next();
        String org_sttr = s;
        String str = "";
        int len = s.length();
        for (int i = len - 1; i >= 0; i--) {

            str = str + s.charAt(i);

        }
        System.out.println(str);
        if (org_sttr.equals(str)) {
            System.out.println("the string is palindrome");
        } else {
            System.out.println("the string is not palindrome");

        }



//            String S="Manish";
//                // code here
//                String rev ="";;
//                int m=S.length()-1;
//                for(int i=0;i<=m;i++){
//                    rev= S.charAt(i) + rev;
//                }
//        System.out.println(rev);


    }
}
