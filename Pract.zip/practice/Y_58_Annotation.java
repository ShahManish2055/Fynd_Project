package practice;
@FunctionalInterface
interface javalearn{
    void wwe();
//    void wrestling(); functional  interface doesnot have 2 methods.
}
class mango extends over {

    public void fast() {
        System.out.println("this my class");
    }
    @Deprecated
 public int add(int a,int b){
    return a+b;
 }
}
public class Y_58_Annotation {
    public static void main(String[] args) {
        @SuppressWarnings("deprecation")
mango m=new mango();
m.fast();
System.out.println(m.add(9,9));

    }
}
