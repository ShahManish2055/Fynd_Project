package practice;
class firstthread extends Thread {   // thread class is lie in java.lang package so it doesnot  need to import and to run Thread  run method is use and start is use to call run mathod .
    public void run() {
        int i = 0;
        while (i < 10) {
            System.out.println("hello i m studing now");
            i++;
        }

        System.out.println("thread1 exit");

    }
}
       class firstthread1 extends Thread {
           public void run() {
               int i = 0;
               while (i < 100) {
                   System.out.println("hello i m eating now");
                   i++;
               }
               System.out.println("thread2 exit");
           }
       }

public class Y_33_ExtendThread{
    public static void main(String[] args) {
        firstthread t = new firstthread();
        firstthread1 t1 = new firstthread1();
        t.start();
//                try{ Thread.sleep(6000);}catch (Exception e){};
        t1.start();
        System.out.println("i m inside main");

    }
}
