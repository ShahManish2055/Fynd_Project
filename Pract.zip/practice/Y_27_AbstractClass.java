package practice;

    abstract class Parent2{
        public Parent2(int a){
            System.out.println("i am parent2 constructor"+" " + a);
        }
        public void sayHello(){
            System.out.println("Hello");
        }
        abstract public void greet();
        abstract public void greet2();
    }
    class Child2 extends Parent2{
        Child2(){
            super(1);

            System.out.println("i m derived class constructor");
        }
     @Override
        public void greet(){
            System.out.println("Good morning");
        }
        @Override
        public void greet2(){
            System.out.println("Good afternoon");
        }
        void mann(){
            System.out.println("kfjkd");
        }
    }

    abstract class Child3 extends Parent2{
        public Child3(int a) {
            super(a);
        } // abstract doesnot create object.
        public void th(){
            System.out.println("I am good");
        }
    }
public class Y_27_AbstractClass {
        public static void main(String[] args) {
            //Parent2 p = new Parent2(); -- error
            Parent2 c = new Child2();// we can create reference of abstract class the problem we get is we cann't assess non  abstract da
            c.greet2();
            c.greet();
            c.sayHello();
           ((Child2) c).mann();

//            Child3 c3 = new Child3(); //-- error
        }
    }



