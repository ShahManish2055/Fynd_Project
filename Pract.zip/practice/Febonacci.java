package practice;
import java.util.*;
public class Febonacci {
   public static int fact(int n){
        if(n==0||n==1){
            return 1;
        }
        else{
        return n*fact(n-1);}

    }
    public static void main(String[] args) {
        //febonacci series
        Scanner s=new Scanner(System.in);
        System.out.print("enter the number:" );
        int d=s.nextInt();
//        int n=0, b=1,t;
//        System.out.println(n);
//        System.out.println(b);
//        for(int i=2; i<d;i++){
//            t=n+b;
//            System.out.println(t);
//            n=b;
//            b=t;
        int b=fact(d);
        System.out.println(b);



//        }
    }
}
