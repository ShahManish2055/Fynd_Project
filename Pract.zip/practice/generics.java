package practice;
class mygenerics1<T1,T2>{
    private  T1 a;
    private  T2 b;


   public mygenerics1(T1 a,T2 b){
        this.a=a;
        this.b=b;
        System.out.println(a+" "+b);
    }
    public void set(T1 a) {
     this.a=a;
    }
    public T1 get() {
        return  a;
    }

}
public class generics {
    public static void main(String[] args){
        mygenerics1<Integer,String> g=new mygenerics1<>(2,"manish");
        g.set(23);
        System.out.println(g.get());
    }
}
