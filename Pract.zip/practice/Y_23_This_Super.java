package practice;


import javax.print.Doc;
    class EkClass{
        int a;
        public int getA() {
            return a;
        }
        void getB(int a,int b){
            System.out.println(a+b);
        }
        EkClass(int a){
            this.a = a; //a=a give wrong output
        }
        public int returnone(){
            return 1;
        }
    }
    class DoClass extends EkClass{
        DoClass(int c,int d,int e){
            super(c);
            super.getB(d,e);

        System.out.println("I am a constructor"); }
    }
public class Y_23_This_Super {
        public static void main(String[] args) {
//            EkClass e = new EkClass(65);
            DoClass d = new DoClass(5,4,7);
            System.out.println(d.getA());
            System.out.println(d.returnone());
        }
    }

