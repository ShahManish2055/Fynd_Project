package practice;
class MyThreadRunnable1 implements Runnable{
//    int c;
public void run(){
    for(int c=0;c<100;c++){

            System.out.println("I am a thread 1 not a threat 1");
        }
    }
}
class MyThreadRunnable2 extends Thread{
//    int c;
    public void run() {
    for(int c=0;c<100;c++){

            System.out.println("I am a thread 2 not a threat 2");
        }
    }
}
public class Y_34_RunnableThreadManish {
    public static void main(String[] args) {
        MyThreadRunnable1 bullet1 = new MyThreadRunnable1();
        Thread gun1 = new Thread(bullet1);

        MyThreadRunnable2 bullet2 = new MyThreadRunnable2();
//        Thread gun2 = new Thread(bullet2);

        gun1.start();
        bullet2.start();
    }
}
//classs t2 implements Runnable{
//@Override
//public void run(){
//        System.out.println("Thread is running");
//        }
//        }
//public class Y_34_RunnableThreadManish {
//    public static void main(String[] args) {
//        t2 obj1 = new t2();
//        Thread t = new Thread(obj1);
//        t.start();
//    }
//}
//


