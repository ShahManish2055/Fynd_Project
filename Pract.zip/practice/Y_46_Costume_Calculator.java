package practice;

import java.util.Scanner;

class MaxInputException extends Exception{
    @Override
    public String toString(){
        return "Max Input Exception occured: Inputs must be less or equal to 100000";
    }
//    @Override
//    public String getMessage(){
//        return "Max Input Exception occured: Inputs must be less or equal to 100000";
//    }
}
class InvalidInputException extends Exception{
    @Override
    public String toString(){
        return "Invalid Input Exception occured: Operand Specified must be one of them: +, -, *, /";
    }
//    @Override
//    public String getMessage(){
//        return "Invalid Input Exception occured: Operand Specified must be one of them: +, -, *, /";
//    }
}
class DivideByZeroException extends Exception{
    @Override
    public String toString(){
        return "Divide By Zero Exception occured: Denominator of the division can not be Zero(0)";
    }
//    @Override
//    public String getMessage(){
//        return "Divide By Zero Exception occured: Denominator of the division can not be Zero(0)";
//    }
}
class MaxMultiplierReachedException extends Exception{
    @Override
    public String toString(){
        return "Max Multiplier Reached Exception occured: The result of multiplication reached above 700000";
    }

//    @Override
//    public String getMessage(){
//        return "Max Multiplier Reached Exception occured";
//    }
}
public class Y_46_Costume_Calculator {
    public static int div(int x,int y) throws DivideByZeroException{
        if(y==0){
            throw new DivideByZeroException();
        }
        return x/y;
    }
    public static int mul(int x,int y) throws MaxMultiplierReachedException{
        int result=x*y;
        if(result>700000){
            throw new MaxMultiplierReachedException();
        }
        return result;
    }
    public static void main(String args[]) {
            Scanner sc = new Scanner(System.in);


            String operand;
            int a;
            int b;
            while (true) {
                System.out.println("Enter first number:");
                a = sc.nextInt();

                System.out.println("Enter second number:");
                b = sc.nextInt();
                if (a > 100000 || b > 100000) {
                    try {
                        throw new MaxInputException();
                    } catch (MaxInputException e) {
                        System.out.println(e);
                        continue;
                    }
                }

                System.out.println("Press + for Addition\nPress - for Subtraction\nPress / for Division\nPress * for Multiplication\npress q to quit");
                operand = sc.next();


                switch (operand) {
                    case "+": {
                        System.out.println("Sum=" + (a + b));
                        break;
                    }
                    case "-": {
                        System.out.println("substraction=" + (a - b));
                        break;
                    }
                    case "*": {
                        try {
                            System.out.println("multplication=" + mul(a, b));
                        } catch (Exception e) {
                            System.out.println(e);

                        }
                        break;
                    }
                    case "/": {
                        try {
                            System.out.println("Division=" + div(a, b));
                        } catch (Exception e) {
                            System.out.println(e);
                        }
                        break;
                    }
                    case "q":
                    case "Q": {
                        System.exit(0);
                    }
                    default: {
                        try {
                            throw new InvalidInputException();
                        } catch (Exception e) {
                            System.out.println(e);
                        }
                        break;
                    }

                }
            }

        }
}
//import java.util.Scanner;
//public class Y_46_Costume_Calculator {
//    public static void main(String[] args) {
//        Scanner s = new Scanner(System.in);
//        System.out.println("enter a number A:");
//        int a = s.nextInt();
//        System.out.println("enter another number B:");
//        int b = s.nextInt();
//        try{
//            if(b==0)
//        }
//        catch(Exception e){
//            System.out.println("can't divide by 0");
//        }
//        System.out.println("enter any operator");
//        char d = s.next().charAt(0);
//
//        if (d == '+')
//            System.out.println("Addition of two numbers are:"+(a + b));
//        else if (d == '-')
//            System.out.println("Subtraction of two numbers are:"+(a - b));
//        else if (d == '/')
//            System.out.println("Division of two numbers are:"+(a / b));
//        else if (d == '*')
//            System.out.println("Multiplication of two numbers are:"+(a * b));
//        else
//            System.out.println("operator invalid");
//
//    }
//}
