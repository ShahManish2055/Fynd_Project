package practice;
import java.util.*;

public class Y_50_HashingProgram {
        public static <set> void main(String[] args) {
            HashMap<Integer,String> myHashSet = new HashMap<>(6, 0.5f);
            HashSet<Integer> a= new HashSet<>();
            HashSet<Integer> HashSet= new HashSet<>();
            myHashSet.put(13,"mgdmn");
            myHashSet.put(8,"kjfn");
            myHashSet.put(3,"kjnfn");
            myHashSet.put(11,"lsfm");
            myHashSet.put(12,"kfjsn");

            myHashSet.put(11,"kflfmf");
            Set<Integer> i=myHashSet.keySet();
            for(int m:i){
                System.out.println(m+":"+myHashSet.get(m));
            }
            System.out.println(".............");
            for(Map.Entry<Integer,String> e:myHashSet.entrySet()){
                System.out.println(e.getKey()+":"+e.getValue());
            }
            System.out.println(myHashSet);
            System.out.println(myHashSet.size());

            a.add(6);
            a.add(8);
            a.add(3);
            a.add(11);
            System.out.println(a);

            HashSet.add(6);
            HashSet.add(8);
            HashSet.add(3);
            HashSet.add(11);
            HashSet.add(11);
            System.out.println(HashSet);


        }
    }
