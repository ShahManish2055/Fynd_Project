package practice;
import java.util.Scanner;
//import java.sql.SQLOutput;

public class UserInput {
    public static void main(String[] args) {
        System.out.print("enter the number:");
        Scanner m=new Scanner(System.in);
        int n=m.nextInt();
        System.out.println(n);
    }
}
