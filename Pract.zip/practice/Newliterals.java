package practice;

public class Newliterals {
    public static void main(String[] args) {
        byte age=34;
        int age1=34;
        long agelong=34232L;
        char ch= 'A';
        float f1=4.9f;
        double d1=43.4D;
        boolean a=true;
        String str="manish";
        System.out.println(agelong);
        System.out.println(str);

    }
}
