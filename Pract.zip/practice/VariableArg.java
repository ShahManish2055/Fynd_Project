package practice;

public class VariableArg {
    static int sum(int b,int ...a) {  //here int b show that we  need to have atleast one argument
        int add = 0;
        for (int i : a)
           add +=i;

        return add;
    }
        public static void main(String [] args){
            System.out.println("sum of elements is:" + sum(3, 4, 4));
            System.out.println("sum of elements is:" + sum(3, 4,7,656, 4));
            System.out.println("sum of elements is:" + sum(3, 4,3,5,4,8, 4));
//            System.out.println("sum of elements is:" + sum());//  here there should be 1 fix argument if definition contains fix parameter
            System.out.println("sum of elements is:" + sum(3));
        }

}
