package practice;


    class Cylender{
     private   int radius;
       private int height;
      public  void setValue(int Radius,int Height) {
         radius = Radius;
          height = Height;
      }
      public  double getValue(){
//          System.out.println(radius);
//          System.out.println(height);
          return Math.PI * radius * radius * height;
        }
    }
public class Y_20_PracticeSet {
    public static void main(String[] args) {
        Cylender c=new Cylender();
        c.setValue(22,32);
       double d= c.getValue();
        System.out.println("area of cylender is"+ d);

    }

}
