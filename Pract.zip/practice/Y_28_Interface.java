package practice;
    interface Bicycle{
        int a = 45;
        void applyBrake(int decrement);
        void speedUp(int increment);
        void run();
    }

    interface HornBicycle{
        int x = 45;
        void blowHornK3g();
        void blowHornmhn();
        void run();
    }

    class AvonCycle implements Bicycle, HornBicycle{
        //public int x = 5;
        int w;
       public void run(){
           System.out.println("manish");
        }
        void blowHorn(){
            System.out.println("Pee Pee Poo Poo");
        }

        public void applyBrake(int decrement){
            System.out.println("Applying Brake");
        }
        public void speedUp(int increment){
            System.out.println("Applying SpeedUP");
            System.out.println( w=increment);
        }
        public void blowHornK3g(){
            System.out.println("Kabhi khushi kabhi gum pee pee pee pee");
        }
        public void blowHornmhn(){
            System.out.println("Main hoon naa po po po po");
        }
    }
public class Y_28_Interface {
        public static void main(String[] args) {
            AvonCycle cyclemanish = new AvonCycle();
            cyclemanish.blowHorn();
            cyclemanish.run();
            cyclemanish.applyBrake(1);
            // You can create properties in Interfaces
            System.out.println(cyclemanish.a);
            System.out.println(cyclemanish.x);
            cyclemanish.speedUp( 23);

            // You cannot modify the properties in Interfaces as they are final
            // cycleHarry.a = 454;
            //System.out.println(cycleHarry.a);

            cyclemanish.blowHornK3g();
            cyclemanish.blowHornmhn();
        }
    }


