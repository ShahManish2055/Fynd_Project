package practice;
import java.util.*;

public class Collection {
    public static void main(String [] args){
        HashMap<String,Integer> h=new HashMap<>();
        h.put("manish",34);
        h.put("ram",3);
        h.put("h",4);
        h.put("man",342);
        h.put("",8);

        System.out.println(h);
     if(!h.containsKey("ram")){
         System.out.println( h.put("ram",8));


     }
        System.out.println(h);

//        Set<String> s=h.keySet();//it returns the key of the hashmap
//        for(String key:s){
//            System.out.println(key+" " + h.get(key));
//        }
//
//        System.out.println(h.get("manish"));
//        System.out.println(h.containsKey("manish"));
//        System.out.println(h.containsKey("shah"));
//        System.out.println(h.containsValue(34));
//        System.out.println(h.containsValue(454));
//        System.out.println(h.replace("manish",22));
//        System.out.println(h);
//        System.out.println(h.remove("manish"));
//        System.out.println(h.putIfAbsent("shah",343));
//
//        System.out.println(h);

//---------------------------------------------------------------------
//        List<Integer> i=new Vector<>();
//        List<Integer> i1=new Vector<>();
//
//        i.add(2);
//        i.add(3);
//        i.add(5);
//        i.add(36);
//        i.add(0);
//        i.set(0,77);
//        i1.add(42);
//        i.addAll(0,i1);
////        System.out.println(i.capacity());
//        System.out.println("size of vector:"+ i.size());
//
//        System.out.println(i.get(0));
//        System.out.println(i);
//        System.out.println(i.indexOf(2));
//        System.out.println(i.lastIndexOf(2));
//        Collections.sort(i);
//        i.clear();
//        System.out.println(i);
//        System.out.println(i.contains(2));

//        ----------------------------------------------------------------


        ArrayDeque<Integer> ad1 = new ArrayDeque<>();

//        ad1.add(6);
//        ad1.add(56);
//        ad1.add(9);
//        ad1.addFirst(5);
//        System.out.println(ad1);
////                ad1.pollFirst(); //deletes 5
////                ad1.removeFirst(); //deletes 6
//        ad1.pollLast(); //deletes 9
//        ad1.removeLast(); //deletes 56
//        System.out.println(ad1);
//        System.out.println(ad1.getFirst());
//        System.out.println(ad1.getLast());
//        System.out.println(ad1.peekFirst());
//        System.out.println(ad1.peekLast());


//        PriorityQueue<Integer> ad = new PriorityQueue<>();
//        ad.add(6);
//        ad.add(56);
//        ad.add(9);
//        ad.add(2);
//       System.out.println(ad.peek());
//        System.out.println(ad.poll());
//        System.out.println(ad);


//it doesnot print in sorted order
//        HashSet<Integer> ad = new HashSet<>();
//        ad.add(6);
//        ad.add(56);
//        ad.add(6);
//        ad.add(9);
//        ad.add(2);
//        ad.add(2);
//
//        System.out.println(ad);

//        it print the elements in sorted order
//        Set<Integer> ad = new TreeSet<>();
//        ad.add(6);
//        ad.add(56);
//        ad.add(6);
//        ad.add(9);
//        ad.add(2);
//        ad.add(2);
//
//        System.out.println(ad);

//it print the element as it is the way we add
//        Set<Integer> ad = new LinkedHashSet<>();
//        ad.add(6);
//        ad.add(56);
//        ad.add(6);
//        ad.add(9);
//        ad.add(2);
//        ad.add(2);
//
//        System.out.println(ad);

//        Array Class
//  int [] arr={2,4,3,6,9,0,8};
//  Arrays.sort(arr);
//  for(int a:arr) {
//      System.out.print(" " + a);
//  }
//        System.out.println();
//
//        int [] arr1={1,2,3,4,5,5};
//int x=Arrays.binarySearch(arr1,3);
//        System.out.println(x);


//        Collection class
              List<Integer> ad = new ArrayList<>();
        ad.add(6);
        ad.add(56);
        ad.add(6);
        ad.add(9);
        ad.add(2);
        ad.add(2);
        System.out.println(ad);
        System.out.println(Collections.max(ad));
        System.out.println(Collections.min(ad));
        Collections.sort(ad);
        System.out.println(ad);


        Stack<String> stack = new Stack  <String>();
        stack.push("Ayush");
        stack.push("Garvit");
        stack.push("Amit");
        stack.push("Ashish");
        stack.push("Garima");
        stack.pop();
        System.out.println(stack);
        System.out.println();
//        ------------------------------------------------------------------
        String s="the quick brown fox jump over lazy dog";
        String [] p=s.split(" " );
        TreeSet<String> t=new TreeSet<>();
        t.addAll(Arrays.asList(p));
        for(String st :t){
            System.out.println(st);
        }


    }
}
