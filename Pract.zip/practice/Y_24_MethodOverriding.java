package practice;
class over{
    int a=7;
    public int b=8;
    public  void fast(){
        System.out.println("this is overriding 1");
    }
    public void slow(){
        System.out.println("i wanna be a skill coder");
    }
}
class ridding extends over{
    public void fast(){   //SAME METHOD NAME AS CLASS A SO CALLED OVERRIDING ,it should have same parameters.
        System.out.println("this is overriding 2");
    }

    public static  void fast(int a){
        System.out.println("i m static overloading: " + a);
    }
}
public class Y_24_MethodOverriding {
    public static void main(String [] args){

        ridding a=new ridding(); // if the method is override then  subclass method invoke first rather  then parent so to invoke the method of parent individual object is created.
        a.fast();
        ridding.fast(3);
        a.slow();
//         over b=new over();
//        b.fast();



    }
}
