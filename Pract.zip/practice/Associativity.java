package practice;

public class Associativity {
    public static void main(String[] args) {
        int a=6*5-34/2;
        int b=60/5-34*2; //* & / have left associativity so computation start from left to right
        System.out.println(a);
        System.out.println(b);
//   ----------------------------------------------------------------------------
        int x=6;
        int y=1;
        int k=x*y/2;
        System.out.println(k);
    }
}
