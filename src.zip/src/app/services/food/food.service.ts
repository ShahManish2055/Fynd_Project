import { Injectable } from '@angular/core';
import { Foods } from 'src/app/shared/models/food';
import {Tag} from 'src/app/shared/models/tag';
@Injectable({
  providedIn: 'root'
})
export class FoodService {

  constructor() { }

  getFoodById(id:number):Foods{
    return this.getAll().find(food => food.id == id)!;
  }

  getAllFoodTag(tag:string):Foods[]{
return tag=="All"? this.getAll():this.getAll().filter(food => food.tags?.includes(tag));

}

getAllTag():Tag[]{
return[
  {name:'All',count:8},
  {name:'FastFood',count:4},
  {name:'Lunch',count:5},
  {name:'Humburger',count:1},
  {name:'Fry',count:1},
  {name:'Soup',count:1},
];
}


getAll():Foods[]{
  return[
{
  id:1,
  name:'Hot Pepper Jelly Sauce for Lamb',
  cookTime:'10-20',
  price:20,
  favorite:true,
  origins:['italy',' uk'],
  star:4.5,
  imageUrl:  '/assets/img1.jpg',
  tags:['FastFood','Lunch'],
},
{
  id:2,
  name:'pork Loin Roast with Apple Cider Sauce',
  cookTime:'10-25',
  price:80,
  favorite:false,
  origins:['italy',' japan'],
  star:4.5,
  imageUrl:   '/assets/img2.jpg',
  tags:['FastFood','Lunch'],
},
{
  id:3,
  name:'Grilled Caesar Salad',
  cookTime:'5-20',
  price:60,
  favorite:true,
  origins:['italy',' germany'],
  star:4.5,
  imageUrl:  'assets/img3.jpg',
  tags:['Fry'],
},
{
  id:4,
  name:'Egg Pasta',
  cookTime:'30-35',
  price:40,
  favorite:false,
  origins:['italy',' thiland'],
  star:4.5,
  imageUrl:  'assets/img4.jpg',
  tags:['FastFood','Lunch'],
},
{
  id:5,
  name:'Chicken Thali',
  cookTime:'10-30',
  price:20,
  favorite:false,
  origins:['italy',' swis'],
  star:4.5,
  imageUrl:   'assets/img5.jpg',
  tags:['Lunch'],
},
{
  id:6,
  name:'Burger',
  cookTime:'30-40',
  price:330,
  favorite:true,
  origins:['italy',' london', ' honkong' ],
  star:4.5,
  imageUrl:  '/assets/img6.jpg',
  tags:['Humburger'],
},
{
  id:7,
  name:'Beeren Obstsalat',
  cookTime:'10-25',
  price:200,
  favorite:false,
  origins:['italy',' Aus'],
  star:4.5,
  imageUrl:  '/assets/img7.jpg',
  tags:['FastFood','Pizza','Lunch'],
},
{
  id:8,
  name:'Cocomo Canggu',
  cookTime:'15-30',
  price:206,
  favorite:true,
  origins:['italy',' usa'],
  star:4.5,
  imageUrl:  '/assets/img8.jpg',
  tags:['Soup'],
},
  ];
}

}
