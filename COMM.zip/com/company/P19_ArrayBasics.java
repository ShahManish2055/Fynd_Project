package com.company;

import practice.MethodOverloading;

  class  cat{
  static   int a=0;
   static void walk(){
       System.out.println(a);
   }

}

class Student {

    String s;
    char c;
    static int st=10;

  public  void run(){
      int v=10;
      System.out.println(v+"....."+st);
      ++v;++st;
    }
        }

public class P19_ArrayBasics {
     int a=34;

    public static void main(String[] args) {
        Student[] s1=new Student[2];

         Student s=new Student();
       s.run();
        s.run();
        System.out.println("--------------------------");

        Object []d={"kjf",3,"hbasdff",4,3,4};
        for(Object ob:d){
            System.out.print(ob+" ");
        }

//you can say class name is a user define type
//if i m making object of   P19_ArrayBasics this means i m making varible of type   P19_ArrayBasics.

        P19_ArrayBasics e=new P19_ArrayBasics();

        System.out.println(e.a);
        // we dont need to import the class if we are in same package
        MethodOverloading pkg=new MethodOverloading();
        pkg.foo();



    }


}
