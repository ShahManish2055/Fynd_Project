package com.company;

//class Outer{
//    static int a=98;
//   static class inner{
//        void in(){
//            System.out.println(a);
//        }
//    }
//        }
class Outer{
     int a=98;
     class inner{
        void in(){
            System.out.println(a);
        }
    }
}

public class InnerOuterClass {
    public static void main(String[] args) {
//   Outer.inner i=new Outer.inner();
//   i.in();

        Outer o=new Outer();
        Outer.inner i=o.new inner();
        i.in();



        }
    }


