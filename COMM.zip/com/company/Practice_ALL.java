package com.company;

import java.util.Scanner;

public class Practice_ALL {
    public static void main(String[] args) {
        String s="manish33u";
        int count =0;
        for (int i=0;i<s.length();i++) {
            if (Character.isLetter(s.charAt(i))){
                count++;
            }
        }
        System.out.println("count of letter is: "+count);

             int c=0;
        for (int i=0;i<s.length();i++) {
            if (Character.isDigit(s.charAt(i))){
                c++;
            }
        }
        System.out.println("count of digit is: "+c);

//-----------------------------------------

        int n=371;
        int arm=n;
        int sum=0;
        while(n!=0){
          int  temp1=n%10;
            sum=sum+(temp1*temp1*temp1);
            n=n/10;
        }
        if(arm==sum){
            System.out.println("is armstrong");
        }
        else {
            System.out.println("not");
        }

        int []a={3,4,7,9,20,30};
        Scanner sc=new Scanner(System.in);
        System.out.println("enter search element: ");
        int search=sc.nextInt();
        int low=0;
        int high=a.length-1;

        while(low<=high){
            int mid=(low+high)/2;
            if(a[mid]==search){
                System.out.println("index of Elementn is: " + ++mid);
                break;
            }
            else if(a[mid]>search){
                high=mid-1;
            }
            else if(a[mid]<search) {
                low=mid+1;
            }
        }
        if(low>high){
            System.out.println("element not found");
        }

        for(int i=0;i<a.length-1;i++){
            if(a[i]==search){
                System.out.println("index is: "+ ++i);
            }

        }
        // ---------------------------------------------------------
        int b=16;
        String st="";
        while(b>0){
            int temp2=b%2;
            st=temp2+st;
            b=b/2;
        }
        System.out.println(st);
        int d=Integer.parseInt(st);
        System.out.println(d);

        int sum1=0;
        int i=0;
        while(d>0){
            int dec=d%10;
            sum1=sum1 + dec*(int)Math.pow(2,i++);
            d=d/10;
        }
        System.out.println(sum1);

//----------------------------------------------------------------

        int arr[]={68,0,2,4,3,5};
        for(int p=0;p<arr.length;p++){
            for(int q=0;q<arr.length-p-1;q++){
                if(arr[q]>arr[q+1]){
                    int temp=arr[q];
                    arr[q]=arr[q+1];
                    arr[q+1]=temp;
                }
            }
        }
        for(int p=0;p<arr.length;p++){
            System.out.print(arr[p]+" ");
        }

        System.out.println();
//---------------------------------------------------------------------
        Scanner sc1=new Scanner(System.in);
        System.out.println("enter the number of febbonice you want: ");
        int n1=sc1.nextInt();
        System.out.print(a1+" "+b1+" ");
        feb(n1-2);
    }
    static int a1=0;
    static int b1=1;
   static void feb(int i){
       if(i>=1) {
           int c = a1 + b1;
           System.out.print(c+" ");
           a1 = b1;
           b1 = c;
           feb(i - 1);
       }
    }

    }


