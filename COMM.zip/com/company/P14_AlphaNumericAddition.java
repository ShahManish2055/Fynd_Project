package com.company;

public class P14_AlphaNumericAddition {
    public static void main(String[] args) {
        String s="";
        int sum=0;
        int count=0;
        String str="m34a8ni9s7h2 ";// if there is number in last value then to read that it has to take space or alphabate character so that it can  go to else statement   for addition
        for(int i=0;i<str.length();i++){
            if(Character.isDigit(str.charAt(i))){
                s=s+str.charAt(i);

            }
            else {
                try{
                    sum = sum + Integer.valueOf(s);
                    s = "";
                    count++;
                }
                catch(Exception e){

                    }


//

            }
        }
        System.out.println("sum of numbers in the String is: "+ sum);
        System.out.println("the number present in the String is :"+ count);
    }
}
