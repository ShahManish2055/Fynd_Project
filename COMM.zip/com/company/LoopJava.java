package com.company;

import java.util.Scanner;

public class LoopJava {

    public static void main(String[] args) {
            System.out.println("enter a number");
            Scanner p = new Scanner(System.in);
            int m = p.nextInt();

            for(int i = 0; i < m; ++i) {
                for(int j = 0; j <= i; ++j) {
                    System.out.print("manish");
                    System.out.print("\t");
                }

                System.out.println();
            }

        }
    }

