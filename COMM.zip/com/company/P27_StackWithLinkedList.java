package com.company;

import java.util.Scanner;

public class P27_StackWithLinkedList {
    static class Node{
        int data ;
        Node next;
        Node(int data){
            this.data=data;
            this.next=null;
        }
    }
    Node top=null;
    public void push(){
        int data,n,m,p;
        Scanner sc=new Scanner(System.in);
            System.out.println("Enter data");
            data=sc.nextInt();
            Node new_node=new Node(data);
            if(top==null){
                top=new_node;
            }
            else{
                new_node.next=top;
                top=new_node;
            }
    }
    public void pop(){
        if(top==null){
            System.out.println("Stack is empty");
        }
        else{
            top=top.next;
            System.out.println("Element Successfully POP");
        }
    }
  public void display(){
        if(top==null){
            System.out.println("Stack is Underflow");
        }
        else{
        Node temp=top;
        while(temp!=null){
            System.out.println(temp.data);
            temp=temp.next;
        }
        }
}
    public static void main(String[] args) {

        P27_StackWithLinkedList s=new P27_StackWithLinkedList();
        int i;
        Scanner sc=new Scanner(System.in);
        int a;
        do {
            System.out.println("enter 1 for push,2 for pop and 3 for display");
            a = sc.nextInt();
            switch (a) {
                case 1: {
                    s.push();
                    break;
                }
                case 2: {
                    s.pop();
                    break;
                }
                case 3: {
                    s.display();
                    break;
                }
            }

            System.out.println("enter 1 if you want to continue Operation and enter any number to exit: ");
            i = sc.nextInt();
        }
        while (i==1);

    }
}
