package com.company;
import java.util.*;
//import java.lang.Character;
public class PracticeToggleCase {
            public static void main(String args[] ){
                Scanner s = new Scanner(System.in);
                System.out.println("enter string: ");
                String name = s.nextLine();
                System.out.println("Hi, " + name + ".");    // Writing output to STDOUT
                char[] c=name.toCharArray();
                for(int i=0; i<c.length;i++){
                    if(Character.isUpperCase(c[i])){
                        c[i]=Character.toLowerCase(c[i]);
                    }
                    else{
                        c[i]=Character.toUpperCase(c[i]);
                    }
                    System.out.print(c[i]);
                }    // Write your code here

            }
}







//    TreeMap<String, Double>  hack =new TreeMap<String, Double>();
//
//                hack.put("John", new  Double(76.5));
//
//                hack.put("Mike", new Double(87.3));
//
//                hack.put("Alice", new Double(78.2));
//
//                hack.put("Bob", new Double (73.4));
//
//                Set<?> set = hack.entrySet();
//
//                Iterator<?> i = set.iterator();
//
//                while(i.hasNext())
//
//    {
//
//        @SuppressWarnings("rawtypes")
//
//        Map.Entry me = (Map.Entry) i.next();
//
//        System.out.print(me.getKey() + " : ");
//
//        System.out.println(me.getValue());
//
//    }
//                    double percentage= ((Double)hack.get("Mike")).doubleValue();
//
//
//
//                    hack.put("Mike", new Double(percentage));
//
//                    System.out.println("Paul's new balance:"+ hack.get("Mike"));



