package com.company;
import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.*;
class Manishh extends JFrame{
    Manishh(){
super("Whatsapp");  // it is calling  JFrame constructor
        setLayout(new FlowLayout()); //now it shows all the  JLabel contain in top-middle.
        setVisible(true);
        setSize(500,500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // if we don't use this then inspite of cutting off to GUI it doesnot stop to run so this method is use to stop GUI totally.

//     the above code should be use in almost all GUI code.
//.............................................................................................................................................................................
        JLabel l=new JLabel("i m making GUI");
        JLabel l1=new JLabel("welcome to microsoft world"); // this  override above actually it shows like stack the last  string shows up .so to overcome setlayout is use.
        add(l);
        add(l1);
    }
}
public class Swingproject {
    public static void main(String[] arg){
        Manishh m=new Manishh();

//JFrame j=new JFrame("Whatsapp");
//     JLabel l=new JLabel("i m making GUI");
//        j.add(l);
//j.setVisible(true);
//j.setSize(400,400);
    }
}
