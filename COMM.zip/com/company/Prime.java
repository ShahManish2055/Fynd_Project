package com.company;
import java.util.Scanner;
public class Prime {
    public static void main(String[] args) {
        int []a=new int[1000];
        int k=1;
        for(int j=2;j<=1000;j++) {
         int count=0;
            for (int i = 1; i <=j; i++) {

                if (j% i== 0) {
                    count++;

                }
            }
            if (count == 2) {

                a[k]=j;

                    System.out.println("enter number is prime i.e:" + a[k]);
                k++;
                }
            }

        System.out.println("enter any position:");
        Scanner s=new Scanner(System.in);
        int b=s.nextInt();
        System.out.println("the prime number is:"+a[b]);
        }
    }

