package com.company;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

class aw extends JFrame implements ActionListener {
    JLabel j,j1,j2;
    JTextField l,l1;
    JButton b;
    aw(){
        super("Information");
        setVisible(true);
        setSize(500,500);
        setLayout(new FlowLayout());
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        j=new JLabel("User_Input:");
        l= new JTextField(30);
         j1=new JLabel("Password:");
        l1=new JTextField(20);
         b=new JButton("click");
        j2=new JLabel("Result");
        add(j);
        add(l);
        add(j1);
        add(l1);
        add(b);
        add(j2);
        b.addActionListener( this);
    }
    public void actionPerformed(ActionEvent e) {
        if (l.getText().equals("abc") && (l1.getText().equals("123"))) {
            j2.setText(String.valueOf("Success login!"));
        } else {
            j2.setText(String.valueOf("Invalid login!"));
        }
    }
}

public class AwtP {
    public static void main(String[] args){
        aw s=new aw();
    }
}
