package com.company;

public class P4_GreatestAmongNumber {
    public static void main(String[] args) {
        int []a={2,5,8,9,4,9,395,58,9,7,1,0};
        int max=0;
        int secmax=0;
         for(int i=0;i<a.length;i++) {
             if (a[i] > max) {
                 secmax = max;
                 max = a[i];
             }
          else if(a[i]!=max && a[i]>secmax){
                  secmax = a[i];
             }
         }
        System.out.println("Higest value of array is: "+max);
        System.out.println("Second Higest number : "+secmax);
    }
}
