package com.company;


    class manish
    {
        public void methodA()
        {
            System.out.println("i m methodA");
        }
    }
    class shah extends manish
    {
        public void methodB()
        {
            System.out.println("i m methodB");
        }
    }
    class lol extends manish
    {
        public void methodC()
        {
            System.out.println("i m methodC");
        }
    }

        public class Hierarchical_inheritance {
            public static void main(String[] args) {
                shah obj1 = new shah();
                lol obj2 = new lol();
//All classes can access the method of class Animal
                obj1.methodA();
                obj1.methodB();
                obj2.methodC();
                obj2.methodA();

            }
        }


