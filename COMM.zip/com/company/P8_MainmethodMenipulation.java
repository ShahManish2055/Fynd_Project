package com.company;

public class P8_MainmethodMenipulation {

//    Case I:OVERLOADING OF METHOD

//    public static void main(String[] args) {
//        System.out.println(" i m String  Main Method");
//        int i  []={1,3,4};
//        main(i);
//    }
//
//    public static void main(int[] args) {
//        System.out.println("i m Interger Mian Method");
//    }


//    CASE II: INHERITANCE OF MAIN METHOD   /  WE CAN SAY MAIN METHOD OVERRIDING
    public static void main(String[] args) {
        System.out.println("I M MAIN METHOD");
        for(int i=0;i<args.length;i++) {
            System.out.println(args[i]);
        }
    }
}

class c extends  P8_MainmethodMenipulation{
    public static void main(String[] args) {

        System.out.println("I M INHERITED MAIN METHOD");
        String [] s={"manish","Shah","1903101"};
//        String [] s={};
        P8_MainmethodMenipulation .main(s);
    }
}