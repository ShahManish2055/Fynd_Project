package com.company;
import java.util.*;
public class S {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        int n = 0;
        String s = "Shreya";
        String ss = "shdtd";
        System.out.println("Enter 1 for if \n 2 for if else \n 0 to quit");
        n = sc.nextInt();

        while (n!=0){
            switch (n){

                case 0:
                    System.out.println("Exit");
                    break;
                case 1:
                    // if else

                    if (s == "Shreya") {
                        System.out.println("Hello Shreya!!!");
                    } else {
                        System.out.println("Hello User");
                    }
                    break;
                case 2:
                    // else if

                    if (s == "Shrey") {
                        System.out.println("hello shrey");
                    } else if (ss == "Shreya") {
                        System.out.println("Hello from else if");
                    } else {
                        System.out.println("Hello new user");
                    }
                    break;
                default:
                    System.out.println("Invalid input");
            }
            n--;


        }



    }

}


