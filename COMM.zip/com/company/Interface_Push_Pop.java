package com.company;
interface top{
    void push();
    void pop();
}
//interface down extends top{
//    void pop();
//}
class stack implements top{
    public void push(){
        System.out.println("hello i m push method ");
    }
    public void pop(){
        System.out.println("hello i m pop method");
    }

    public void run(){
        System.out.println("m class method");
    }

        }
public class Interface_Push_Pop {
    public static void main(String[] args) {
        top manish = new stack();
        manish.push();
        manish.pop();
//        manish.run();
    }
}
