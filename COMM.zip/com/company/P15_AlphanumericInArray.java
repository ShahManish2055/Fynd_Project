package com.company;

public class P15_AlphanumericInArray {
    public static void main(String[] args) {
        String [] str={"A1n2","b3v2","h4 "};
        int sum=0;
        String  st="";
        for(int i=0;i<str.length;i++){
           String s= str[i];

            for(int j=0;j<s.length();j++){
              if(Character.isDigit(s.charAt(j))){
                  st=s.charAt(j)+st;
              }
              else{
try{
                      sum=sum+Integer.parseInt(st);
                      st="";}
catch(Exception e){}
              }
            }
        }
        System.out.println(sum);
    }
}
