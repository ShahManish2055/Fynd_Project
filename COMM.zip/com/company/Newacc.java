package com.company;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class Newacc extends JFrame implements ActionListener
{
    JLabel l1, l2, l3;
    JTextField tf1, tf2, tf3;
    JButton btn1,btn2;
    Newacc()
    {
        setVisible(true);
        setSize(700, 700);
        setLayout(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setTitle("swing in java");
        l1 = new JLabel("Enter Roll Number");
        l2 = new JLabel("Enter Name");
        l3 = new JLabel("Enter DOB");
        tf1 = new JTextField();
        tf2 = new JTextField();
        tf3 = new JTextField();
        btn1 = new JButton("Submit");
        btn2 = new JButton("Clear");
        btn1.addActionListener(this);
        btn2.addActionListener(this);
        l1.setBounds(80, 70, 200, 30);
        l2.setBounds(80, 110, 200, 30);
        l3.setBounds(80, 150, 200, 30);

        tf1.setBounds(300, 70, 200, 30);
        tf2.setBounds(300, 110, 200, 30);

        tf3.setBounds(300, 150, 200, 30);

        btn1.setBounds(100, 350, 100, 30);
        btn2.setBounds(200, 350, 100, 30);
        add(l1);
        add(tf1);
        add(l2);
        add(tf2);
        add(l3);
        add(tf3);

        add(btn1);
        add(btn2);
    }
    public void actionPerformed(ActionEvent e)
    {
        if (e.getSource() == btn2)
        {
            tf1.setText("");
            tf2.setText("");
            tf3.setText("");
        }
        if(e.getSource()==btn1)
        {
            System.exit(0);
        }
    }
    public static void main(String args[])
    {
        new Newacc();
    }
}

