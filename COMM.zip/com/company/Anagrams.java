package com.company;
import java.util.Arrays;
import java.util.Scanner;

public class Anagrams {
//   int val=10;
    public static void main(String[] args) {
//        Anagrams a=new Anagrams();
//        System.out.println(a.val);

        String s="manish kjsanf";
        String s1="nishma kjsanf";

//        System.out.println(s.charAt(0));
        char[] c=s.toCharArray();
        char[] d=s1.toCharArray();
        Arrays.sort(c);
        Arrays.sort(d);

        for(char e:c){
            System.out.print(e);
        }
//        System.out.println(c[0]);
        System.out.println();
        if(Arrays.equals(c,d)){
            System.out.println("anagram");
        }
        else{
            System.out.println("not anagram");
        }
//
//        for(int i=0;i<c.length;i++){
//
//        }

        Scanner sc=new Scanner(System.in);
        System.out.println("enter the number: ");
        int n=sc.nextInt();
        int rev=0,r;
        int m=n;
        while(n>0){
            r=n%10;
            System.out.print(rev);
            rev=(rev*10)+r;
            n=n/10;

        }
        System.out.println();
        if(m==rev){
            System.out.println("Palindrome");
        }
        else{
            System.out.println("not Palindrome");
        }

    }


}
