package com.company;

import java.util.Stack;

public class P23_Collection_FrameWork {
    public static void main(String[] args) {
        Stack<Integer> s=new Stack<>();
        s.push(9);
        s.push(4);
        s.push(8);
        s.push(7);
        s.push(6);
        s.push(2);
        s.add(4);
//        s.pop();
//        s.pop();
        System.out.println(s.peek());
        System.out.println(s.search(9));
        System.out.println(s);
        System.out.println(s.isEmpty());
    }
}
