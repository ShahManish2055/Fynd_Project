package com.company;
import java.util.Scanner;

public class ThirdJava {
    public static void main(String[] args) {
        System.out.println("taking input from the user");
        Scanner m=new Scanner(System.in);
//        System.out.println("enter number1");
//        int a=m.nextInt();
//        System.out.println("enter number2");
//        int b=m.nextInt();
//        int sum=a+b;
//        System.out.print("sum=");
//        System.out.println(sum);
//        boolean b=m.hasNextInt();
//        System.out.println(b);
//        System.out.println("enter String");
//        String str=m.next();
//        System.out.println(str);
        System.out.println("enter String");
        String str=m.nextLine();
        System.out.println(str);
    }
}
