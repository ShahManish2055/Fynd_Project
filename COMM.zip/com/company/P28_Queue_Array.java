package com.company;

import java.util.Scanner;

class queue{
    int f =-1;
    int r=-1;
    int n=7;
    int q[]=new int[n];
    Scanner sc=new Scanner(System.in);
    void Enqueue(){

        if(r==(n-1)){
            System.out.println("Overflow");
        }
        else{
            System.out.println("enter the data: ");
            int i=sc.nextInt();
            if(f==-1 && r==-1){
                f=0;
                r=0;
                q[r]=i;
            }
            else{
                r=r+1;
                q[r]=i;
            }
        }
    }

    void Dequeue(){
        if(f==-1 && r==-1){
            System.out.println("Underflow");

        }
        else{
          f=f+1;
            System.out.println("Item deleted ");
        }
    }
    void display(){
        System.out.println("items are: ");
        for(int j=f;j<=r;j++){
            System.out.println(q[j]);
        }
    }

}
public class P28_Queue_Array {
    public static void main(String[] args) {
        queue s=new queue();
        int i;
        Scanner sc=new Scanner(System.in);
        int a;
        do {
            System.out.println("enter 1 for Enqueue,2 for Dequeue and 3 for display");
            a = sc.nextInt();
            switch (a) {
                case 1: {
                    s.Enqueue();
                    break;
                }
                case 2: {
                    s.Dequeue();
                    break;
                }
                case 3: {
                    s.display();
                    break;
                }
            }

            System.out.println("enter 1 if you want to continue Operation and enter any number to exit: ");
            i = sc.nextInt();
        }
        while (i==1);
    }
}


