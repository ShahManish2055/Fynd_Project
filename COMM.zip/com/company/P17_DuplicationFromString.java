package com.company;
import java.util.Arrays;
import java.util.HashSet;

public class P17_DuplicationFromString {
    public static void main(String[] args) {
        String s="manish@!s%ha*h";
        for(int i=0;i<s.length();i++){
            if(Character.isLetter(s.charAt(i))){
                System.out.print(s.charAt(i));
            }
        }
        System.out.println();

        String str ="the quick brown fox jumps over the lazy dog";
        String str1= str.toUpperCase();
        char []a=str1.toCharArray();
        Arrays.sort(a);
        System.out.println();

        HashSet<Character> st=new HashSet<>();
        HashSet<Character> st2=new HashSet<>();
        for(char x: a){
            st.add(x);
        }

        for(char st1:st){
            System.out.print(st1);
        }

        for(int i=0;i<str.length();i++){
            st2.add(str.charAt(i));
        }

         for(char st1:st2){
             System.out.print(st1);
         }





    }
}
