package com.company;

    interface e
    {
        void show();

    }
    // interface f
    interface  f extends e// we can not create objects of interfaces but we can create reference variables
    {
        void display();
        void show();
    }

//    class C implements e,f
class C implements f
    {
        void dispC()
        {
            System.out.println("Inside dispC ");
        }
        public void show()
        {
            System.out.println("hello");
        }
        public void display()
        {
            System.out.println("Inside C class");
        }
    }



public class C12_Interfacee {
        public static void main(String a[])
        {
            C ob = new C();
            ob.show();
            ob.display();
            ob.dispC();
        }
    }

