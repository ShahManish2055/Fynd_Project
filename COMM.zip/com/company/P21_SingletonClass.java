package com.company;
class singleton {
    private singleton() {
    }
    private static singleton Instance;

    final static singleton myInstance() {
        if (Instance == null) {
            Instance = new singleton();
        }
        return Instance;
    }
    void run(){
        System.out.println("i m in sinngleton class");
    }
}
public class P21_SingletonClass {
    public static void main(String[] args) {
//        singleton s= new singleton(); it is not possible
        singleton s=singleton.myInstance();
        singleton s1=singleton.myInstance();
        s.run();
        s.run();
    }
}
