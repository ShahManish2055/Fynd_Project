package com.company;
class Add
{
    private int a,b;
    Add(Add d)
    {
        a=d.a;
        b=d.b;
    }
    Add(int x,int y)
    {
        a=x;
        b=y;
    }
    void sum()
    {
        int sum1=a+b;
        System.out.println("Sum of a and b :"+sum1);
    }
}
class ExAddcons
{
    public static void main(String arg[])
    {
        var A=new Add(15,8);
        Add A1=new Add(A);
        A1.sum();
    }
}

//class rocket{
//    void spacex(rocket c){
//        System.out.println("jhbfjsb");
//    }
//}
//public class PassingObjToMethod {
//    public static void main(String[] args) {
//        rocket n=new rocket();
//        n.spacex(n);
//    }
//}
