package com.company;

public class P10_ObjectClass {
    public static void main(String[] args) {
        Object o=new Object();
        Object s=new String();
//        String SO=  new Object();  // it is not possible because Object is the parent class of all the other  class so we can not take reference of child class and make object of parent  class i.e Object Class.
//        String SO= (String) new Object();
        Object b=9;
        Object c=9;
        System.out.println(b);
        System.out.println(b.equals(c));
        System.out.println(b.getClass().getName());
        System.out.println(o.hashCode());
    }
}
