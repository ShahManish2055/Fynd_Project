package com.company;
class Dog{
     void disp(char f)
//    char j=f;
    {
        System.out.println(f);
    }
    void disp(char d, int num)
//    char k=d;
    {
        System.out.println(d + " "+ num);
    }

    public int run(int a){
        int b;
        b=a;
        return b;
    }
}
class Cat extends Dog{
    //int b;
    public void cat(int c){
//b=c;
        System.out.println(" hello i m cat " + c  +  " legs ");
    }
}
public class Interitance_1{
    public static void main(String[] args)
    {
        Cat d=new Cat();
        int e;
        e=d.run(4);
        System.out.println(" This is our custom class "+e);
        d.cat(5);
        d.disp('a');
        d.disp('a',3);
    }
}

