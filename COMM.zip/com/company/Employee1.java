package com.company;

class Employee{
    int salary;
    int employeeno;
   Employee(){

       salary=50000;
       employeeno=50;
   }
    void Elements(){
        System.out.println("employee number:"+employeeno);
       System.out.println("salary per employee:"+salary);

   }
}
class manager extends Employee{

String compname,name,managersalary;


    manager(String companee,String namee,String maanagersalary){
        compname=companee;
        name=namee;
        managersalary=maanagersalary;
//        System.out.println("3.name of company:"+compname);
//        System.out.println("4.name of ceo:"+name);
//        System.out.println("5.income of ceo:"+managersalary);

    }
 void get(){

     System.out.println("3.name of company:"+compname);
     System.out.println("4.name of ceo:"+name);
     System.out.println("5.income of ceo:"+managersalary);

 }

}

public class Employee1 {
    public static void main(String[] args) {


        Employee e = new Employee();
        e.Elements();
        manager m=new manager("tesla","elon musk","2billion");
        manager p=m;
      //  new manager("tesla","elon musk","2billion");
        m.get();
        m.Elements();

        p.get();
        p.Elements();
    }
}