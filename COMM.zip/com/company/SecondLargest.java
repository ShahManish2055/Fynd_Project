package com.company;
import java.util.*;

 class SecondLargest {
   static int largestValue(int a[]){
        int largest=0;
        for(int i=0;i<a.length;i++){
            if(a[i]>a[largest]){
                largest=i;
            }
        }
        return largest;
    }
    static void secondlargest(int a[],int b){
        int res=0;
       for(int i=0;i<a.length;i++){

           if(a[i]!=a[b]){
//               if(res==-1)
//                   res=i;
               if(a[i+1]>a[res]){
                   res=i;
               }
           }
       }
        System.out.println("sencond largest number is: "+a[res]);
    }
    public static void main(String[] args) {
        int [] a={5,12,10,80,2,0};
        Arrays.sort(a);
        for(int b:a){
            System.out.println(b);
        }
       int largest = largestValue(a);
        System.out.println("latgest number is: "+a[largest]);

        secondlargest(a,largest);
    }
}
