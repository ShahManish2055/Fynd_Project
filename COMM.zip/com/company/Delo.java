package com.company;
import java.util.Scanner;

interface hoo{
void n();
void m();
}

interface too extends hoo{
    void w();
    void p();
}
class woo implements hoo{
   public void n(){
       System.out.println("n");
   }
   public void m(){
       System.out.println("m");
   }

   public void w(){
       System.out.println("o");
   }
   public void p(){
       System.out.println("p");
   }
}
public class Delo {
    public static void main(String[] args) {
//        hoo ob=new woo();
//        ob.w();
//        ob.p();
//        ob.n();
        int [] a=new int[6];
        Scanner sc=new Scanner(System.in);
        for(int i=0;i<a.length;i++) {
            System.out.print("enter the values:");
        a[i]=sc.nextInt();
        }

        System.out.print("the values in array are:" );
        for(int i=0;i<a.length;i++) {
            System.out.print( a[i]+" ");
        }

        for(int i=0;i<a.length;i++){
            for(int j=1;j<a.length-i;j++){
                if(a[j]>a[j-1]){

                }
            }
        }
        for(int i=0;i<a.length;i++){
            System.out.println(a[i]);
        }
    }
}
