package com.company;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
class swng extends JFrame implements ActionListener {
    JTextField t;
    JTextField t1;
    JButton b;
    JLabel l;
    swng() {
        super("arthemetic operation");
        setLayout(new FlowLayout());
        setVisible(true);
        setSize(500, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
         t=new JTextField(30);
         t1=new JTextField(30);
         b=new JButton("ok");
         l=new JLabel("result");
        b.addActionListener(this);
        add(t);
        add(t1);
        add(b);
        add(l);
    }
    @Override
    public void actionPerformed(ActionEvent e) {
      int num1= Integer.parseInt(t.getText());
      int num2= Integer.parseInt(t1.getText());
     int value= num1+num2;
     l.setText(value+"");
    }
}
public class SwingAddition {
    public static void main(String[] args) {
        swng s=new swng();

    }

}
