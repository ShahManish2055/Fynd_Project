package com.company;

interface  game{
    void football();
    void vollyball();
    int r=90;


    static void inter(){
        System.out.println("i m static method in interface...");
    }

    default void ronaldo(){
        System.out.println("Ronaldo got 19 awards in football...");
    }

}
abstract class player {

    public player(){
        System.out.println("i m constructor");
    }
    abstract void bestplayer();
//    abstract  void hye();{
//        System.out.println("this is also possible");
//    }

    void GameNumber(){
        System.out.println("many games...");
    }


}



class award extends player implements  game{
    public void bestplayer(){

    }
//    public void hye(){
//
//    }
   public void football(){

    }
   public void vollyball(){
        System.out.println(" i m vollyball method");
    }
}

public class P13_Interface_Abstract {
    public static void main(String[] args) {
        award a=new award();
        a.bestplayer();
        a.ronaldo();
        a.GameNumber();
        game.inter();
        System.out.println(game.r);


    }
}
