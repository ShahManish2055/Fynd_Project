package com.company;

//public class GarbageCollector {
    /* Garbage collection:
If we have created data on heap at the runtime, dynamic memory management/ allocation
malloc() and calloc() .
free();// release the dynamically allocated memory : Programmer
//dyamically allocated memory using garbage collector implicitely or automatically, garbage collector JVM */
//garbage collector deals with finding and deleting the garbage from memory,it tracks each & every object avilable in jvm heap space and remove  unused ones.


     class x
    {
        int a; // data member of class X
        x(int c) // parameterized constructor
        {
            a = c;
        }
        public void display()
        {
            System.out.println("a ====" + a);
        }
        public void finalize(){System.out.println("object is garbage collected");}
    }



    class Demo1
    {

        public static void main (String[] args)
        {

            x ob1 = new x(10); // ob1 is called as reference variable
            x ob2 = new x(21); // System.gc();
            new x(32);
            ob1 = ob2; // ob1 = 200
            System.gc(); // Explicite call to the gc method
            ob1.display();
            ob2.display(); // void free(pointer variable); // free(p); // delete ref_variable

        }
    }

