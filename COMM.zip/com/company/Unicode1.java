package com.company;

public class Unicode1 {
    public static void main(String[] args) {
        int i=65;
        System.out.println((char)i);
    }
}
