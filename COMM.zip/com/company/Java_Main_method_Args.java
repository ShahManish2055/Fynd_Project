package com.company;

public class Java_Main_method_Args {
        public static void main(String[] args){

            System.out.println(args[0]);  // pass agruments by going through run and put there arguments accordingly
           System.out.println(args[1]);
            System.out.println(args[2]); // actually these all arguments i passed is String type so we are converting it into Integer type.
           int d=args.length;
            System.out.println(d);
            
         int a=Integer.parseInt(args[0]);
         int b=Integer.parseInt(args[1]);
            int c=a+b;
            System.out.println(c);
        }
    }

