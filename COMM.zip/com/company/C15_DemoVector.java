package com.company;
/* Vector:
Vector is a dynamic array and we have to save non-homogenious data elements together in Vector.
Constructors :
1. Vector(); // initial size of 10 elements
2. Vector(int size);
3. Vector(int size, int increments);
java.util
Mehods:
addElement(item);
elementAt(int loc);
int size() ;
int capacity();
removeElement(item);
removeElementsAt(int loc); */
import java.util.*;
public class C15_DemoVector
    {
        public static void main(String args[])
        {
            Vector v = new Vector(3, 2);// by default its capacity is 10 and if we exceed this value then vector increase by double of it but to minimize it we pass parameters to Vector constructor where it shows that first parameter is Capacity and 2nd is the increment of capacity when it exceed value .........
            System.out.println("Initial size: " + v.size());
            System.out.println("Initial capacity: " + v.capacity());
            v.addElement ("Rahul");
            v.addElement (10);
            v.addElement ("kedar");
            v.addElement ("samir");
            v.addElement ("sami");
            v.insertElementAt ("Manish",2);
            v.add(2,"shah");
            System.out.println(v.get(2));
            System.out.println(v.get(3));
            System.out.println("Initial size: " + v.size());
            System.out.println("Initial capacity: " + v.capacity());
        }
    }

