import java.io.*;
import java.util.*;

class Solution {

    public static void main(String[] args) {

        Scanner sc= new Scanner(System.in);

        int a= sc.nextInt();
        double db= sc.nextDouble();
        sc.nextLine();
        String str= sc.nextLine();
        System.out.println("String: "+str);
        System.out.println ("Double: " + db);
        System.out.println ("Int: " + a);
    }
}