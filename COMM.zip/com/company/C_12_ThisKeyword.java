package com.company;

public class C_12_ThisKeyword {

    C_12_ThisKeyword(){
        this(4);
        System.out.println("this automatically call default constructor");

    }
    C_12_ThisKeyword(int a){
        System.out.println("i m called from default constructor");
    }
    public static void main(String[] args) {
        C_12_ThisKeyword c=new C_12_ThisKeyword();

    }
}
