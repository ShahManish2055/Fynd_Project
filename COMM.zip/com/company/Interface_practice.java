package com.company;
interface  I{
    void run();
}
interface Placement {
    void run();
}
public class Interface_practice implements I,Placement{
    public void run(){
        System.out.println("Interface A & B Both..");
    }
    public static void main(String[] args) {
Interface_practice obj=new Interface_practice();
obj.run();

    }
}
