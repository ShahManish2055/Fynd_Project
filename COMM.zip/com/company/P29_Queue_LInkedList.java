package com.company;


import java.util.Scanner;

public class P29_Queue_LInkedList {
    static class Node{
        int data ;
        Node next;
        Node(int data){
            this.data=data;
            this.next=null;
        }
    }
    Node f=null;
    Node r=null;
Scanner sc=new Scanner(System.in);
    public void Enqueue(){
        System.out.println("Enter Data: ");
        int data=sc.nextInt();
        Node new_node=new Node(data);
        if(f==null){
            f=new_node;
            r=new_node;
        }
        else{
            r.next=new_node;
            r=new_node;
        }
    }

        public void Dequeue(){
         if(f==null){
             System.out.println("underflow");
         }
         else{
             f=f.next;
             System.out.println("Deleted successfully...");
         }
    }
    public void display(){
      Node temp=f;
      while(temp!=null){
          System.out.println(temp.data);
          temp=temp.next;
      }
    }
    public static void main(String[] args) {

        P29_Queue_LInkedList s=new P29_Queue_LInkedList();
        int i;
        Scanner sc=new Scanner(System.in);
        int a;
        do {
            System.out.println("enter 1 for Enqueue,2 for Dequeue and 3 for display");
            a = sc.nextInt();
            switch (a) {
                case 1: {
                    s.Enqueue();
                    break;
                }
                case 2: {
                    s.Dequeue();
                    break;
                }
                case 3: {
                    s.display();
                    break;
                }
            }

            System.out.println("enter 1 if you want to continue Operation and enter any number to exit: ");
            i = sc.nextInt();
        }
        while (i==1);

    }
}


