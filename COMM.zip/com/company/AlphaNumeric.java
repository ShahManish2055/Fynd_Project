package com.company;

public class AlphaNumeric {
    public static void main(String[] args) {
        String t="m1a3n4i5s5";
        int a=0;
        for(int i=0;i<t.length();i++) {
            try {

                char c = t.charAt(i);
                a = a + Integer.parseInt(Character.toString(c));   //you can use String.valueOf(c)

            }

          catch(Exception e){
              System.out.println(e);
            }

        }
        System.out.print("The sum of all numbers in strings is : "+a);


    }
}
