package com.company;

public class P2_FirstnonRepeatingChar {
    public static void main(String[] args) {
        String s = "manishShahma";
//        int count =0;
        for ( int i = 0; i < s.length(); i++) {
            boolean unique=true;
            for (int j = 0; j < s.length(); j++) {
                if (i!=j && s.charAt(i) == s.charAt(j)) {
                    unique = false;
                    break;
                }

            }
            if(unique){
                System.out.println("The non repeating value of given string is: " + s.charAt(i));
                 break;
            }
        }


    }

}