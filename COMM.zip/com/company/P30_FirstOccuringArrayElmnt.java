package com.company;
//this is wrong solution so don't use ur brain here
import java.util.*;
class ap {
    void arrele(int[] a) {
        HashMap<Integer, Integer> count = new HashMap<>();
        for (int i = 0; i < a.length; i++) {
            if (count.containsKey(a[i])) {
                count.put(a[i], count.get(a[i]) + 1);
                if (count.get(a[i]) == 2) {
                    System.out.println(a[i]);
                }

            } else {
                count.put(a[i], 1);
            }
        }
    }
}
public class P30_FirstOccuringArrayElmnt {
    public static void main(String[] args) {
        ap ar = new ap();
        int[] a = {1, 7, 4, 3, 4, 8, 7};
        ar.arrele(a);
    }
}

