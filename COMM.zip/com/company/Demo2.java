/**
 static block: static{
 // body of the static block
 }
 */
//static block

//package com.company;
 class Demo2 {
    static int a =2; // data member initilization
    static int b; // data member declaration
    int c=3; // non static data member
    static void display(int x) // static method
    {
        System.out.println("a = " + a);
        System.out.println("b = " + b);
// System.out.println("c = " + c);
        System.out.println("x = " + x);
    }
    static {
        System.out.println("Static block called");
        b = a * 4;
        a=a*5;
    }
}

class X
{
    public static void main (String[] args) {
        Demo2 obj = new Demo2();
        obj.display(21);
    }
}