package com.company;

//import java.util.Scanner;
class shaah{
    int w=34;
    static int m=88;
}
public class Main {
    static int maanish=9;
   int manish=99;
    public static void main(String[] args) {

	// write your code here
        System.out.print("sum of two numbers is:");//To print in the same line we can use print only
        Main s=new Main();
        shaah r=new shaah();
        int shah=2;
        int sum=s.manish+shah;
        System.out.println(sum);
        System.out.println(maanish);
        System.out.println(shaah.m);// HERE WE CAN SEE THAT FOR STATIC MEMBER WE DON'T NEED TO CREATE OBJECT THOUGH IT HAS DIFFERENT CLASS WE CAN DIRECTLY ACCESS GIVING THE CLASSNAME.MEMBERNAME;
        System.out.println(r.w);// NOTE IT DOES NEED TO TAKE OBJECT.MEMBERNAME COZ IT HAS NOT STATIC MEMBERS.
    }

}
