package com.company;


class r{

    static {
        System.out.println("i m static block");
    }
    static int f=8;
}

public class swaap {
    public static void main(String[] args) {
//
        r b=new r();




        int a=5;
        int fact=1;
        for(int i=a;i>0;i--){
            fact=fact*i;

        }
        System.out.println("factorial of a is: "+fact);
    }
}
