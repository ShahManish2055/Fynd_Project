package com.company;

import java.util.*;
class leapfrog{
    int first(int a ,int b){
        return a+b;
    }
}

class company extends leapfrog{
     int first (int a,int b){
        return 5 * (a+b);
    }
}

public class basics {
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        company l= new company();
        int n =6;
//        System.out.println();
        do{
            if(l.first(4,6) < 100){
                System.out.println("done");
            }
            n--;
        }while(n > 0);
        
        String str ="shreya";
        System.out.println(str.charAt(0));
//        while (true) {
//            System.out.print("Enter a number to find factorial of ? ");
//            int n = s.nextInt();
//            int fact = 1;
//            for (int i = n; i > 0; i--) {
//                fact = fact * i;
//            }
//            System.out.println("factorial of " + n + " is : " + fact);
//        }


    }
}
