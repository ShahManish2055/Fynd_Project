package com.company;

import java.util.Scanner;

class stack1{
    int top =-1;
    int n=7;
    int a[]=new int[n];
    Scanner sc=new Scanner(System.in);
    void push(){
        if(top==(n-1)){
            System.out.println("Overflow");
        }
        else{
            System.out.println("enter data");
            int i=sc.nextInt();
            top=top+1;
            a[top]=i;
            System.out.println("item Inserted");
        }
    }

    void pop(){
        if(top==-1){
            System.out.println("Underflow");

        }
        else{
            top=top-1;
            System.out.println("Item deleted ");
        }

    }
    void display(){
        System.out.println("items are: ");
        for(int j=top;j>=0;j--){
            System.out.println(a[j]);
        }
    }

}
public class P26_Stack {
    public static void main(String[] args) {
       stack1 s=new stack1();
        int i;
        Scanner sc=new Scanner(System.in);
       int a;
       do {
           System.out.println("enter 1 for push,2 for pop and 3 for display");
           a = sc.nextInt();
           switch (a) {
               case 1: {
                   s.push();
                   break;
               }
               case 2: {
                   s.pop();
                   break;
               }
               case 3: {
                   s.display();
                   break;
               }
           }

           System.out.println("enter 1 if you want to continue Operation and enter any number to exit: ");
           i = sc.nextInt();
       }
       while (i==1);
    }
}
