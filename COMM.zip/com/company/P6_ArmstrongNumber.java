package com.company;

public class P6_ArmstrongNumber {

    public static void main(String[] args) {
        int n=370,sum=0,r;
        int org=n;
        while(n>0){
            r=n%10;
            n=n/10;
            sum=sum+ (r*r*r);
        }
        if(org==sum){
            System.out.println("This is Armstrong Number");
        }
        else{
            System.out.println("Not Armstrong Number");
        }
    }
}
