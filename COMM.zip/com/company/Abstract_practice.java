package com.company;

abstract class mainsh{
    abstract void hye();
}
abstract class sah extends manish {
    abstract void you();

    void hye() {
        System.out.println("manish shah is in hye method ..");
    }

    static void sman(){
        System.out.println(" i m static method inside abstract class");
    }
}
    class T extends sah{// we cannot write public specifier in two classes coz if we write public in class we have to write file name as same so in java
//    there should be only one public class and same file name
      public   void you(){
            System.out.println("i m in sah class..");
        }

    }


public abstract class Abstract_practice {  // main method can be inside abstract method coz main method is static method which doesnot required
    //to create object and for abstract class we cannot create object so no need to make class abstract which contains main method.
    public  static void main(String[] args) {
        T obj=new T();
        obj.hye();
        obj.you();
        sah.sman();


    }

}
