package com.company;

public class reverseArray {
    public static void main(String[] args) {
        int a[]={1,4,6,3,6,4};
        for(int i=a.length-1;i>=0;i--){
            System.out.print(a[i]);
        }
    }
}
