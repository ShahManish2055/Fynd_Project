package com.company;
//import java.util.ArrayList;
//import java.util.Scanner;
//public class Fynd {
//        static long m(long x, long y)
//        {
//            if (y == 0)
//                return x;
//            else
//                return m(y, x % y);
//        }
//        static ArrayList<Long> minimumSquares(long L, long B)
//        {
//            ArrayList<Long> arr = new ArrayList<>();
//            long k = 0;
//            long n = 0;
//            k = m(L, B);
//            n = (L * B) / (k * k);
//            arr.add(n);
//            arr.add(k);
//
//            return arr;
//        }

//import java.util.Scanner;
//
//class Solution {
//    public static int noConseBits(int n) {
//        StringBuilder sb=new StringBuilder();
//        int num=n;
//        while(n!=0)
//        {
//            sb.append((n&1));
//            n>>=1;
//        }
//        String s=sb.reverse().toString();
//        int len=s.length();
//        int temp=len-1;
//        int sum=0,c=0;
//        for(int i=0;i<len;i++)
//        {
//            if(s.charAt(i)=='1')
//            {
//                c++;
//                if(c==3)
//                {
//                    sum+=1<<(temp-i);
//                    c=0;
//                }
//            }
//
//            else
//                c=0;
//        }
//        return num-sum;
//    }
//        public static void main(String[] args)
//        {
//            Scanner c=new Scanner(System.in);
//            System.out.println("Enter number: ");
//            int a=c.nextInt();
//            System.out.println(noConseBits(a));
////            System.out.println("Enter second number: ");
////            int b=c.nextInt();
////            System.out.println("the output is: "+ minimumSquares(a, b));
//        }
//
//}

import java.util.*;

//public class Fynd{
//
//    public static int longestPath(ArrayList<Integer>[] graph, int n) {
//        int[] inDegree = new int[n]; // inDegree[i] stores the in-degree of vertex i
//        for (int i = 0; i < n; i++) {
//            for (int j : graph[i]) {
//                inDegree[j]++;
//            }
//        }
//
//        Queue<Integer> queue = new LinkedList<Integer>();
//        for (int i = 0; i < n; i++) {
//            if (inDegree[i] == 0) {
//                queue.add(i);
//            }
//        }
//
//        int[] dp = new int[n]; // dp[i] stores the length of the longest path ending at vertex i
//        Arrays.fill(dp, 1); // initialize all elements to 1
//
//        int maxLength = 1;
//        while (!queue.isEmpty()) {
//            int curr = queue.poll();
//            for (int neighbor : graph[curr]) {
//                dp[neighbor] = Math.max(dp[neighbor], dp[curr] + 1);
//                maxLength = Math.max(maxLength, dp[neighbor]);
//                inDegree[neighbor]--;
//                if (inDegree[neighbor] == 0) {
//                    queue.add(neighbor);
//                }
//            }
//        }
//
//        return maxLength;
//    }
//
//    public static void main(String[] args) {
//
//        ArrayList<Integer>[] G = new ArrayList[5];
//        for (int i = 0; i < 5; i++) {
//            G[i] = new ArrayList<Integer>();
//        }
//        G[0].add(1);
//        G[0].add(2);
//        G[1].add(2);
//        G[2].add(3);
//        G[3].add(4);
//        int n = 5;
//        System.out.println(longestPath(G, n));
//    }
//
//}

//public class Fynd {
//    public static boolean wordBreak(String s, List<String> wordDict) {
//        int n = s.length();
//        boolean[] dp = new boolean[n + 1];
//        dp[0] = true;
//
//        for (int i = 1; i <= n; i++) {
//            for (int j = 0; j < i; j++) {
//                if (dp[j] && wordDict.contains(s.substring(j, i))) {
//                    dp[i] = true;
//                    break;
//                }
//            }
//        }
//
//        return dp[n];
//    }
//
//    public static void main(String[] args) {
//        String s = "leetcode";
//        List<String> dict = List.of("leet", "code");
//        boolean result = wordBreak(s, dict);
//        System.out.println(result);
//    }
//}




