package com.company;
class i    //super class
    {
        int k=10;
        void disp() // override method
        {
            System.out.println("Value of k in disp method of super class = "+k);
        }
        void show(){
            System.out.println("hyee this can't be run from the reference class name.....");

        }
        void play(){
            System.out.println("hyee play from here...");

        }

    }
    class d extends i// sub class
    {
        int l;
        d(int a, int b) // parameterized constructor
        {
            l= a;
            k = b;
        }
        void disp() // overridden method
        {
            System.out.println("Value of k in superclass = "+ k);
            System.out.println("Value of l in sub class = "+ l);

           super.disp(); // super keyword use to call super class method coz here two display method have same name
            // so the one execute with the object made by the same class.
        }
//        void show(){
//            System.out.println("hyee this can't be run from the reference class name.....");
//
//        } it doesnot run

    }
public class C_11_super {
        public static void main (String args []){

            i ob = new d(10, 20);      // EVEN IT WORKS IF WE MAKE OBJECT OF CLASS d AND refer TO CLASS a
//            d ob = new d(10, 20);
            ob.disp();
            ob.show();
            ob.play();
        }
    }

