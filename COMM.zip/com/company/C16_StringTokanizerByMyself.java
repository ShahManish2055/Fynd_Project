package com.company;
import java.util.StringTokenizer;
public class C16_StringTokanizerByMyself {
    public static void main(String[] args) {
        StringTokenizer s = new StringTokenizer("hello i m writing stringtokenizer code", " ", false);
        System.out.println(s.countTokens());
        while (s.hasMoreTokens()) {
            System.out.println(s.nextToken());
//
//            int a=9;
//            int b=4;
////            System.out.println(a+++b);
//            String st=new String("gshdgsuhgiu");
//            System.out.println(st);
        }
    }

}