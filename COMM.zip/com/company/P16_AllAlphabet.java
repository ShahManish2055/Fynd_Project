package com.company;
import java.util.*;
class Solutio
{
    //Function to check if a string is Pangram or not.
    public static boolean checkPangram  (String str) {

        String s=str.trim();
        System.out.println(s);
        char [] c=s.toCharArray();
        for(int i=0;i<c.length;i++) {
           Character.toUpperCase(c[i]);
        }
        Arrays.sort(c);

        System.out.println(c);
        String v="ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        char [] d=v.toCharArray();
        Arrays.sort(d);

        if(Arrays.equals(c,d)) {
            return true;
        }
        else{
            return false;
        }

    }
}
public class P16_AllAlphabet {
    public static void main(String[] args) {
       Solutio ob=new Solutio();
        System.out.println( ob.checkPangram("The quick brown fox jumps over the lazy dog"));




    }
}
