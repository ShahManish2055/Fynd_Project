package com.company;
import practice.*;

class Datatype{
    int a;
    float b;
    String c;
    Datatype next;
    Datatype(int c){
        try {
            Datatype node = new Datatype(c);
            System.out.println(node);
        }
        catch (Exception e){
            System.out.println("the exptn"+ e);
        }
        a=3;
        next=null;
    }
}
public class P22_ClassDataType extends Recursion{
    public static void main(String[] args) {
//        Datatype s=new Datatype(2);
//        Recursion c=new Recursion();
        P22_ClassDataType c=new P22_ClassDataType();
        System.out.println("The value of factorial x is: " + c.factorial(4));
//        Datatype t=9

//        Datatype[] h=new Datatype[5];
//        System.out.println(h);

    }

}
