package com.company;

public class Methodhidding {
    public static void main(String[] args) {
        System.out.println("parent");
//        m.main( args);
    }
}
  class m extends Methodhidding{
    public static void main(String[] args) {
        System.out.println("child");
    }
    }

//
//    package com.company;
//
//public class Methodhidding {
//    public static void main(String[] args) {
//        System.out.println("parent");
//    }
//}
//class m extends Methodhidding{
//
//    }

//  package com.company;
//
//public class Methodhidding {
//    public static void main(String[] args) {
//        System.out.println("parent");
////        m.main( args);
//    }
//}
//class m extends Methodhidding{
//    public static void main(int[] args) {
//        System.out.println("child");
//    }
//}