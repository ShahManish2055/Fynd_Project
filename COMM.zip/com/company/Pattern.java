package com.company;
import java.util.Scanner;
public class Pattern {
    public static void main(String[] args) {
//        System.out.println("enter row and column numers:");
//        Scanner m=new Scanner(System.in);
//        Scanner n=new Scanner(System.in);
//        int a=m.nextInt();
//        int b=n.nextInt();
//        for (int i =1; i<=a; i++) {
//            for (int j = 1; j <=b; j++) {
//                if( i==1 || j==1 || i==a ||j==b){
//                    System.out.print("*");
//                }
//                else{
//                    System.out.print(" ");
//                }
//            }
//            System.out.println();
//
//        }
//        ............................................................

//        for (int i = a; i >= 0; i--) {
//            for (int j = 0; j < i; j++) {
//                System.out.print("*");
//            }
//            System.out.println();
//        }
//        .............................................................
//        for (int i = 0; i <= a; i++) {
//            for (int j = 0; j <i; j++) {
//                System.out.print("*");
//            }
//            System.out.println();
//        }

//        ...........................................
//
//        for(int i=1;i<=5;i++) {
//            for(int j=1;j<=i;j++) {
//                System.out.print(j+" ");
//            }
//            System.out.println();
//        }
//        for(int i=5;i>=1;i--) {
//            for(int j=1;j<=i;j++) {
//                System.out.print(j+" ");
//            }
//            System.out.println();
//        }
//        '''''''''''''''''''''''''''''''''''''''''''''''''''
//        for(int i=1;i<=5;i++) {
//            for(int j=1;j<=5-i;j++){
//                System.out.print(" ");
//            }
//            for(int j=1;j<=i;j++) {
//                System.out.print(j);
//
//            }
//            System.out.println();
//        }
//'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
//        for (int i = 1; i <=5; i++) {
//            for (int j = 1; j <=5-i; j++) {
//                System.out.print(" ");
//            }
//            for (int j = 1; j <=i; j++) {
//                System.out.print("*");
//            }
//            System.out.println();
//        }
//        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
//        int sum=0;
//        for(int i=1;i<=5;i++){
//            for(int j=1;j<=i;j++){
//                sum=i+j;
//                if(sum%2==0){
//                    System.out.print(1);
//                }
//                else{
//                    System.out.print(0);
//                }
//            }
//            System.out.println();
//        }
//'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
//        butterfly
//        for(int i=1;i<=8;i++){
//            for(int j=1;j<=i;j++){
//                System.out.print("*");
//            }
//            int spaces=2*(8-i);
//            for(int j=1;j<=spaces;j++){
//                System.out.print(" ");
//            }
//            for(int j=1;j<=i;j++){
//                System.out.print("*");
//            }
//            System.out.println();
//        }
//
//        for(int i=8;i>=1;i--){
//            for(int j=1;j<=i;j++){
//                System.out.print("*");
//            }
//            int spaces=2*(8-i);
//            for(int j=1;j<=spaces;j++){
//                System.out.print(" ");
//            }
//            for(int j=1;j<=i;j++){
//                System.out.print("*");
//            }
//            System.out.println();
//        }
//        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
// rhombus
//        for(int i=1;i<=10;i++){
//            for(int j=1;j<=(10-i);j++){
//                System.out.print(" ");
//            }
//            for(int j=1;j<=10;j++){
//                System.out.print("*");
//            }
//            System.out.println();
//        }
//''''''''''''''''''''''''''''''''''''''''''''''
//        pyamid
        for(int i=1;i<=5;i++){
            for(int j=1;j<=(5-i);j++){
                System.out.print(" ");
            }
            for(int j=1;j<=i;j++){
                System.out.print(i+" ");
            }
            System.out.println();
        }


    }
}



