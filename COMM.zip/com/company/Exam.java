package com.company;
import javax.swing.*;
import java.awt.*;
//import java.awt.event.ActionListener;
class sw extends JFrame{

    sw() {
        super("GUI for information" );
        setLayout(new FlowLayout());
        setVisible(true);
        setSize(500, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        JLabel l1 = new JLabel("Name:");
        JTextField t = new JTextField(30);
        JLabel l2 = new JLabel("rollno:");
        JTextField t1 = new JTextField(30);
        JLabel l3 = new JLabel("DOB:");
        JTextField t3 = new JTextField(30);
        JButton b = new JButton("ok");
        JLabel l = new JLabel("result");
        add(l1);
        add(t);
        add(l2);
        add(t1);
        add(l3);
        add(t3);
        add(b);
        add(l);

    }
}
public class Exam {
    public static void main(String[] args) {
        sw s = new sw();

    }

}


