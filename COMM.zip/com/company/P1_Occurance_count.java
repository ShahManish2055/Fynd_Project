package com.company;

public class P1_Occurance_count {
    public static void main(String[] args) {
        String s="java programming java opps";
        System.out.println(s.getClass().getName());// it gives type of variable
        int count= 0;
//        char []c=s.toCharArray();
        for(int i=0;i<s.length();i++){
            if(s.charAt(i)=='a'){
             count=count+1;
            }
        }
        System.out.println("number of 'a' character is :" + count);
    }
}
