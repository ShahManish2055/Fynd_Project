package com.company;

import java.util.Scanner;

class A //super class or base class or parent class
    {
        int a,b; // data members
        A() // default constructor
        {
            a=10;
            b= 20;
        }
        void dispA() //member function
        {
            System.out.println("Value of a is = " + a);
            System.out.println("Value of b is = " + b);
        }
    }
    class B extends A // derived class or child class or subclass
    {
        int k;
        B() // default constructor
        {
            k=30;
        }
        void dispB() // member function
        {
//            System.out.println("Value of a is = " + a);
//            System.out.println("Value of b is = " + b);
            System.out.println("Value of k is = " + k);
        }
    }

//    '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
class excp extends Exception{
    excp(String st){
//        super("under age exception..");
        super(st);
    }

}
public class Inheritance {
    public static void main(String[] args) {

//        A ra = new B();
//     Object o=new B();
//     o.dispB(); error

//        B ram = new B();
//        A hari = new A();
//        ram.dispB();
//        ram.dispA();

//        nullPointer Exception
//        String s=null;
//        System.out.println(s.toUpperCase());
//'''''''''''''''''''''''''''''''''''''''
//int a[]={1,3,4,5,7};
Scanner sc=new Scanner(System.in);

//        System.out.println("Enter the index : ");
//int s=sc.nextInt();
//        System.out.println("Enter number which you want tot divide");
//        int d= sc.nextInt();
//
//try{
//    System.out.println(a[s]);
//    System.out.println(a[s]/d);
//}
//catch (ArrayIndexOutOfBoundsException e){
//    System.out.println("this is arrayoutofboundexception"+e);
//}
//catch (ArithmeticException e){
//
//    System.out.println("this is arthmetic exception :"+e);
//}
        System.out.println("enter the age: ");
        int s=sc.nextInt();
        try {
            if (s < 18) {
//                throw new excp();
                throw new excp("you are  below age exception..");
            }
            else{
                System.out.println("your age match");
            }
        }
        catch (Exception e){
//            System.out.println(e);
            e.printStackTrace();
            System.out.println("finished");
        }
    }
}
