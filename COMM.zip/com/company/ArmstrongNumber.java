package com.company;
import java.util.Scanner;
public class ArmstrongNumber {
    public static void main(String[] args) {
        System.out.print("enter any three digits number:");
    int number,num, temp, total = 0;
    Scanner a=new Scanner(System.in);
     num=a.nextInt();
     number=num;
        while (number != 0)
    {
        temp = number % 10;
        total = total + temp*temp*temp;
        number /= 10;
        

    }

        if(total == num)
            System.out.println(num + " is an Armstrong number");
        else
                System.out.println(num + " is not an Armstrong number");





}
}

