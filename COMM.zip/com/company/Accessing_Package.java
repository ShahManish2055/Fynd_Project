package com.company;
import practice.MethodOverloading;
//import practice.ChildOfDerived;

interface  cd{
    void carry();
}
interface  p{
    void car();
}
abstract class ab implements cd,p{
    abstract void man();
}


 class dog extends ab{
    public void carry(){

    }
     void man(){

     }
   public   void car(){}

        private void eat() {
            System.out.println("i m private  method");
        }
//    dog() {
//            eat();
//    }
}


public class Accessing_Package {
    public static void main(String[] args) {
        MethodOverloading m=new MethodOverloading();
        m.foo();
//        dog d=new dog();
//        d.eat();


    }
}
