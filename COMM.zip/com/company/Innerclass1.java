package com.company;

 class outer {
    /**
     */
//    class Outer // Outer class
//    {
    static int outer_x = 100;
        void test() // outer class member method
        {

            Inner i = new Inner();
            i.i_disp(); // call to the inner class method
        }

        class Inner // inner class
        {
            void i_disp()
            {
                System.out.println("outer_x = " + outer_x);
            }
        }
    }

class Innerclass1 {

    //        public Innerclass1() {
//        }
    public static void main (String[] args) {
        outer o = new outer();
        o.test();

    }
}
//}
