package com.company;

public class P7_PerfectNumber {
    public static void main(String[] args) {
        int n=28;
        int sum=0;
        for(int i=1;i<n;i++){
            if(n%i==0) {
                sum = sum + i;
            }
        }
        if(n==sum) {
            System.out.println("The number is Perfect number");
        }
        else{
            System.out.println("The number is not perfect number ");
        }
    }
}
