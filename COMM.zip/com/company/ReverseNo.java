package com.company;
import java.util.*;
public class ReverseNo {
    public static void main(String[] args) {
        Scanner sc =new Scanner(System.in);

    }
}
