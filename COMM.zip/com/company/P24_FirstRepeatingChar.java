package com.company;

public class P24_FirstRepeatingChar {
    public static void main(String[] args) {
        String s="manishshah";
        for(int i=0;i<s.length();i++){
            boolean b=false;
            for(int j=0;j<s.length();j++){
                if(i!=j && s.charAt(i)==s.charAt(j)){
                    b=true;
                    break;
                }
            }
            if(b){
                System.out.println(s.charAt(i));
                break;
            }

        }
    }
}
