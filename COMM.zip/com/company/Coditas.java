package com.company;
import java.util.*;
public class Coditas {
//    static int fib( int n){
//        if (n == 0 || n == 1) {
//            return n;
//        } else {
//            return fib(n - 1) + fib(n - 2);
//        }}
    public static void main(String[] args) {
        int a[]={2,5,4,3,4,3,9,7,8,7};
        for(int i=0;i<a.length-1;i++){
            for(int j=0;j<a.length-i-1;j++){
                if(a[j]>a[j+1]){
                    int temp=a[j];
                    a[j]=a[j+1];
                    a[j+1]=temp;
                }

            }        }
        for(int i=0;i<a.length;i++){
        System.out.print(a[i]);}
//        System.out.println(fib(8));
//        Scanner s=new Scanner(System.in);

//        String s1=s.next();
//        String st=s1;
//        int len=s1.length();
//        String rev="";
//        for(int i=len-1;i>=0;i--) {
//             rev=rev+s1.charAt(i);
//        }
//        System.out.println(rev);
//        if(st.equals(rev)){
//            System.out.println("this string is palindrom");
//        }
//        else{
//            System.out.println("not");
//        }
//int n=1;
//        for(int i=5;i>=0;i--){
//            for(int j=1;j<=i;j++){
//                System.out.print(j+n);
//            }
//            n++;
//            System.out.println();
//        }


        }

    }


