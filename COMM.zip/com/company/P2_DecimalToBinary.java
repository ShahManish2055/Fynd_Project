package com.company;

public class P2_DecimalToBinary {

    public static void main(String[] args) {
        int a=32;
        String c="";

        while(a>0) {
            int b = a % 2;
            c=b+c;
            a = a / 2;
        }
        int w=Integer.parseInt(c);
        System.out.println("the Decimal to Binary conversion of given number is : "+ w);

        System.out.println("NOW TO FIND THE SAME NUMBER REVERSE");
    int  t=0,i=0;
        while(w > 0){
         int r=w%10;
         t=t + r* (int)Math.pow(2,i++);
         w=w/10;

        }
        System.out.print("The Binary to Decimal conversion of number is :"+ t);

    }


}
