package com.company;
import java.util.Scanner;
import java.util.Scanner;

public class P5_LeapYear {
    public static void main(String[] args) {
        while (true) {
            Scanner s = new Scanner(System.in);
            System.out.print("Enter Year: ");
            int a = s.nextInt();
            if (a % 100 == 0 && a % 400 == 0 || a % 100 != 0 && a % 4 == 0) { // we have divided by 100 because we are trying to find
//                weather the input is centure or not.
                System.out.println("Enter year is Leap_Year: " + a);
            } else {
                System.out.println("Enter year is not leap Year: " + a);
            }
        }
    }
}
