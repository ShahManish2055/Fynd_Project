package com.company;
class learn{
    int a,b;
    learn(int a){
        System.out.println(a);
    }

    learn(int a,int b){
        this(5);
        this.a=a;
        this.b=b;
        System.out.println(this);
    }

}
public class thisKeyword {
    public static void main(String[] args) {
        learn l=new learn(2,4);
        System.out.println(l.a + l.b);
        System.out.println(l);
//        learn l1=new learn();
    }
}
