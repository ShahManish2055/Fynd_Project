package com.company;

public class P18_Split {
    public static void main(String[] args) {
//        String s = "i m,mannish@t.h";
//        String[] strarr = s.split("[,@.! ]", 4);
//        for (String s1 : strarr) {
//            System.out.println(s1);


          String s3="He is a very very good boy, isn't he?";
            String[] starr = s3.split("[^A-Za-z']+");
            for (String s2 : starr) {
                System.out.println(s2);
            }
        }
    }

