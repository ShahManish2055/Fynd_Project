package com.company;
import java.util.*;

class Rotation{

//    Rotation from left shift
//    void number_ofRotation(int []a,int k) {
//        for (int i = 0; i<k;i++){
//            final_rotation(a);
//        }
//    }
//    void final_rotation(int[] a){
//       int temp=a[0];
//        for(int i=0;i<a.length-1;i++){
//            a[i]=a[i+1];
//        }
//        a[a.length-1]=temp;
//    }
//     void Print(int []a){
//        for(int i=0;i<a.length;i++){
//            System.out.print(a[i] + " ");
//        }
//     }
//    Rotation from right shift

void number_ofRotation(int []a,int k) {
    for (int i = 0; i<k;i++){
        final_rotation(a);
    }
}
    void final_rotation(int[] a){
        int temp=a[a.length-1];
        for(int i=a.length-1;i>0;i--){
            a[i]=a[i-1];
        }
        a[0]=temp;
    }
    void Print(int []a){
        for(int i=0;i<a.length;i++){
            System.out.print(a[i] + " ");
        }
    }

    void Print(int []a,int k){
        System.out.println();
        System.out.print("The rotated arrays are: ");
        for(int i=0;i<k;i++){
            System.out.print(a[i] + " ");
        }
    }
}
public class P20_RotationOfArray {
    public static void main(String[] args) {
        int a[]={1,10,20,47,59,63,75,88,99,107,120,133,155,162,176,188,199,200,210,222};
        Rotation r=new Rotation();
        Scanner sc=new Scanner(System.in);
        System.out.print("ENTER THE NUMBER FOR ROTATIONS : ");
        int k=sc.nextInt();
        r.number_ofRotation(a,k);
        r.Print(a);
        r.Print(a,k);

    }
}
