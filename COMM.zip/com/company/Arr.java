package com.company;

import java.util.Arrays;
import java.util.Collections;

//1,2,3,8,7,8,7
public class Arr {
    public static void main(String[] args){
        int[] a={1,2,3,8,7,8,7,10};
//        for(int i=0;i<a.length-1;i++) {
//            for(int j=0;j<a.length-1-i;j++){
//            if (a[j]>a[j+1]){
//                int temp=a[j];
//                a[j]=a[j+1];
//                a[j+1]=temp;
//            }
//            }
//        }
//            for(int t=0;t<a.length;t++){
//                System.out.println(a[t]);
//
//        }
//        System.out.println("the second largest number is "+ a[a.length-3]);
////        Arrays.max(a);
//        Arrays.sort(a);
//        for(int s:a)
//        System.out.println(a[a.length-3]);
        int max=0;
        int secmax=0;
        for(int i=0;i<a.length;i++){
            if(a[i]>max){
                secmax=max;
                max=a[i];
            }
            if(max!=a[i] && secmax<a[i]){
                secmax=a[i];
            }
        }
        System.out.println(max+" "+ secmax);
    }
}
