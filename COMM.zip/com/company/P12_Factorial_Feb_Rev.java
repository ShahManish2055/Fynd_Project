package com.company;

import java.util.Scanner;

public class P12_Factorial_Feb_Rev {

//    FACTORIAL................

//    static int fact(int a){
//        if(a==1)
//        {
//            return 1;
//        }
//        else {
//            return a * fact(a - 1);
//        }
//    }
//    public static void main(String[] args) {
//        int b=fact(4);
//        System.out.println(b);
//    }

//febonacci series

//    public static void main(String[] args) {
//
//         int a = 0, b = 1, c;
//        System.out.print(a+" "+ b +" ");
//            for(int i=1;i<9;i++){
//
//                     c = a + b;
//                    System.out.print(c + " ");
//                    a = b;
//                    b = c;
//                }}
//
//    }

//fibonacci series
//static int a=0,b=1;
//    static void feb(int n) {
//        for (int i = 0; i <= n; i++) {
//            System.out.print(a + " ");
////            if(i==10){
////                System.out.println(a);
////            }
//            int c = a + b;
//            a = b;
//            b = c;
//        }
//
//    }
//    public static void main(String[] args){
//
//        P12_Factorial_Feb_Rev.feb(10);
//
//    }


//    febonacci series using recursion

//    public static void main(String[] args){
//        feb(10);
//    }
//    static int a=0,b=1;
//    static void feb(int i) {
//            if (i >= 0) {
//                System.out.print(a + " ");
//                int c = a + b;
//                a = b;
//                b = c;
//                feb(i - 1);
//            }
//    }



//    public static void main(String[] args) {
//       int a=4;
//       int b=6;
//       a=a+b;
//       b=a-b;
//       a=a-b;
//        System.out.println(a+" "+b);
//    }

    //    vowels count
//    public static void main(String[] args) {
//        String str = "manish shah";
//        int vowels = 0;
//        int consonants = 0;
//
//        for (int k = 0; k < str.length(); k++) {
////            System.out.println(str.charAt(k));
//            char c = str.charAt(k);
//
//            if (c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u')
//
//                vowels++;
//
//            else
//
//                consonants++;
//
//        }
//        System.out.println(vowels);
//        System.out.println(consonants);
//    }
//}

//    public static void main(String[] args) {
//        String str = "abba";
//
//        String reverse = "";
//
//        int length = str.length();
//
//        for (int i = 0; i < length; i++) {
//
//            reverse = str.charAt(i) + reverse;
//
//        }
//        System.out.println(reverse);
//
//        if(reverse.equals(str)){
//            System.out.println("palendrome "+reverse.equals(str));
//        }
//        else{
//            System.out.println("not palendrome");
//        }
//    }
//}


//palindrome number

//    public static void main(String[] args) {
//        Scanner sc=new Scanner(System.in);
//        System.out.print("Enter number to be reverse : ");
//        int n=sc.nextInt();
//        int org = n;
////        String rev="";
//        int rev=0;
//        while(n>0){
//
//            int a=n%10;
////            rev=rev+a;
//            rev= rev*10 +a;
//            n=n/10;
//
//        }
//
//        System.out.println(org);
////        if(org==Integer.parseInt(rev)){
//        if(org==rev){
//            System.out.println(" Palindrome");
//        }
//        else{
//            System.out.println(" not palindrome");
//        }
//    }
//}

    public static void main(String[] args) {
        int [] a ={22,45,3,65,21,88,97,2};
        int max=0;
        int sec=0;
        for(int i=0;i<a.length;i++){
            if(a[i]>max){
                sec=max;
                max=a[i];
            }
            else if(a[i]!=max && a[i]>sec){
                sec=a[i];
            }
        }

        System.out.println("highest number is : "+ max +  "\nsecond highest number is : " + sec);
    }

}
