package com.company;
public class p17_Indexing_Array {
    public static void main(String[] args) {
        int [] a={1,2,5,4,7,8,11,20};
        int []b=new int[a.length];
        int index=0;
        for(int i=0;i<a.length;i++){
            if(a[i]%2==0){
                b[index]=a[i];
                index++;
            }
        }
        for(int i=0;i<a.length;i++){
            if(a[i]%2!=0){
                b[index]=a[i];
                index++;
            }
        }
        for(int i=0;i<a.length;i++){
            System.out.print(b[i]+",");
        }

    }
}
