package com.company;
public class C14_String_IN_Class
    {
        public static void main(String a[])
        {
            StringBuffer strbuff = new StringBuffer("Amol");
            strbuff.append(" Jagtap");
            strbuff.replace(0,5,"manish");
            strbuff.delete(6,8);
            System.out.println(strbuff);
            StringBuilder sb = new StringBuilder(" Suraj");
            sb.append(" Jagtap");
            System.out.println(sb);
            String s = new String("Samir");
//            String s1 = new String();

            System.out.println(s.concat(" Patil"));
//            System.out.println(s);

        }
    }
