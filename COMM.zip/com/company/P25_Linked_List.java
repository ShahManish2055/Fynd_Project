package com.company;

import java.util.Scanner;

public class P25_Linked_List {
    static  class Node{
        int data;
        Node next ;
        Node(int data){
            this.data=data;
            this.next=null;
        }
    }
    Node head=null;

//    -------------------------------------------------------------------------------------------------------------------
    public void Creation(){
        int data ,n,m,p;
        Scanner sc =new Scanner(System.in);
        do {
            System.out.println("enter data");
            data=sc.nextInt();
            Node new_node=new Node(data);
            if(head==null){
                head=new_node;
            }
            else{
                System.out.println("enter 1 to insert the element in beginning ,enter 2 to insert the element at end,enter 3 to insert the element in where do you want:  ");
                m=sc.nextInt();
                switch(m){
                    case 1:
                        new_node.next=head;
                        head=new_node;
                        break;
                    case 2:
                        Node temp=head;
                        while(temp.next!=null){
                            temp=temp.next;
                        }
                        temp.next=new_node;
                        break;
                    case 3:
                        System.out.println("enter position of node to be inserted");
                        n=sc.nextInt();
                        Node temp1=head;
                        for(int i=0;i<(n-1);i++){
                            temp1=temp1.next;
                        }
                        new_node.next=temp1.next;
                        temp1.next=new_node;
                        break;
                }
            }
            System.out.println("Do you want to add more data if yes ,press : 1");
            p=sc.nextInt();
        }
        while (p==1);
    }


//-----------------------------------------------------------------------------------------------

    public void delete() {
        int data, n, m, p;
        Scanner sc = new Scanner(System.in);
        do {
            if (head == null) {
                System.out.println("LL is Empty");
            } else {
                System.out.println("Enter 1 to delete from beginning,Enter 1 to delete from last,Enter 3 to delete from any position you want: ");
                m = sc.nextInt();
                switch (m) {
                    case 1:
                        Node temp = head;
                        head = temp.next;
                        break;
                    case 2:
                        Node temp1 = head;
                        Node ptr = temp1.next;
                        while (ptr.next != null) {
                            temp1 = ptr;
                            ptr = temp1.next;
                        }
                        temp1.next = null;
                        break;
                    case 3:
                        System.out.println("enter position of node to deleted:");
                        p = sc.nextInt();
                        Node temp2 = head;
                        Node ptr1 = temp2.next;
                        for (int i = 0; i < p - 2; i++) {
                            temp2 = ptr1;
                            ptr1 = temp2.next;
                        }
                        temp2.next = ptr1.next;
                        break;
                }
            }
            System.out.println("Do you want to delete more data if yes ,press : 1");
            n = sc.nextInt();
        }
        while (n == 1) ;
        }

//        ------------------------------------------------------------------------------------------------------------
    public  void traverser(){
           Node temp=head;
           if(head==null){
               System.out.println("LL doesnot exist");
           }
           else{
               while (temp!=null){
                   System.out.print(temp.data+" ");
                   temp=temp.next;
               }
           }
    }

    public static void main(String[] args) {
        P25_Linked_List LNodes=new P25_Linked_List();
        LNodes.Creation();
        LNodes.delete();
        LNodes.traverser();
    }
}
