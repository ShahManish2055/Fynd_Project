package com.company;
import java.util.*;
public class BinarySearch {
    public static void main(String[] args) {
        int[] a={1,3,5,7,8,9};
//        Arrays.sort(a);
        Scanner sc=new Scanner(System.in);
        System.out.println("enter a search elements:");
        int search=sc.nextInt();
       int low=0;
       int high=a.length-1;

       while(low<=high) {
           int mid = (low + high) / 2;
          if(a[mid]==search){
              System.out.println("search value is in index:"+ mid);
              break;
          }
          else if (a[mid] < search) {
               low = mid + 1;
           }
           else {
               high= mid - 1;
           }

       }

if(low>high){
    System.out.println("element not found");
}
    }
}
