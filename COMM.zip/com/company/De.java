package com.company;
import java.util.Arrays;
import java.util.Stack;
//interface o{
//    private void manish(){
//        System.out.println("I m manish from private method of class O ");
//    }
//    default void iD(){
//        manish();
//    }
//    void ram();
//     int s=9;
//
//}
//interface dl extends o{
//void shyam();
//}
import java.sql.SQLOutput;
import java.util.Scanner;

abstract class Ac{
    int a=9;
//    static void t(){}
    abstract void ab();
    Ac(int i){
        System.out.println("i m constructor in AC " + i);
    }
    void ere(){
        System.out.println("i m AC method");
    }

}

 abstract class n extends Ac{
     n(int p){
         super(p);

     }
     void ere(){
         System.out.println("i m n method");
     }

   void m(){
       System.out.println("I m n calss method");
    }

}

class man extends n {
    man(int c) {
        super( c);
    }
    public void ram(){
        System.out.println("hyee ram");
    }
    public void shyam(){
        System.out.println("i m shyam");
    }
    void ab(){
        System.out.println("im ab");
    }


}

//];;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
//abstract class t{
//    int a=8;
//    abstract void manish();
//}
//abstract class u extends t{
//    abstract void shah();
//}
//
//class n extends u{
//    @Override
//    void manish() {
//        System.out.println("i m abstract method");
//    }
//    void shah(){
//        System.out.println(" im extended method");
//    }
//}
public class De {
    static void rotate(int a[],int k){
        for(int i=0;i<k;i++) {
            finalrotate(a);
        }}
       static void finalrotate(int []a){
            int temp=a[0];
            for(int i=0;i<a.length-1;i++){
                a[i]=a[i+1];
            }
            a[a.length-1]=temp;
        }
        static void Print(int [] a) {
            for (int i = 0; i < a.length; i++){
                System.out.print(a[i]+" ");
            }
        }

    public static void main(String[] args) {

//        man ob=new man(2);
//        ob.m();
//        ob.ram();
//        ob.shyam();
//        ob.ab();
//        ob.iD();
//        System.out.println(ob.s);
//        System.out.println(ob.a);
//        ob.ere();
//        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
//        n ob=new n();
//        System.out.println(ob.a);
//        ob.manish();
//        ob.shah();


//        ///////////////////reverse of number
//        String s="mam";
//        String rev="";
//        for(int i=0;i<s.length();i++){
//            rev=s.charAt(i)+rev;
//        }
//        if(s.equals(rev)) {
//            System.out.println("the string is palendrom :" + rev);
//        }
//        else{
//            System.out.println("not palendrom");
//        }


//        ''''''''''''''''''''''''''palendrom
//        Scanner sc=new Scanner(System.in);
//        System.out.println("enter the number");
//        int a=sc.nextInt();
//        int org=a;
//        int revs=0;
//        while(a!=0){
//            int r=a%10;
//            revs=(revs*10)+r;
//            a=a/10;
//        }
//        if(org==revs){
//        System.out.println("palendrom");
//    }
//        else{
//            System.out.println("not palendrom");
//        }

//        String s="m2a34m34 ";
//        String s1="";
//        int sum=0;
//        for(int i=0;i<s.length();i++){
//            if(Character.isDigit(s.charAt(i))) {
//                s1=s1+s.charAt(i);
//            }
//            else{
//                try {
//                    sum = sum + Integer.parseInt(s1);
//                    s1="";
//                }
//                catch(Exception e){
//
//                }
//            }
//        }
//        System.out.println("sum of number is: " + sum);


//Scanner s1=new Scanner(System.in);
//        System.out.println("Enter the number: ");
//int a=s1.nextInt();
//int sum=0;
//for(int i=1;i<a;i++){
//    if(a%i==0){
//        sum=sum+i;
//    }
//}
//if(a==sum){
//    System.out.println("perfect number ..");
//}
//else{
//    System.out.println("not perfect number ..");
//}

//        factorial
//        int a =4;
//        int fact=1;
//        for(int i=a;i>=1;i--){
//            fact=fact*i;
//        }
//        System.out.println("the given number factorial is :"+ fact);

//        febo
//        int a=0,b=1,c;
//        Scanner s3=new Scanner(System.in);
//        System.out.println("enter the number for feb ? ");
//        int ob=s3.nextInt();
//        System.out.print(a+" "+b+" ");
//        for(int i=2;i<ob;i++){
//            c=a+b;
//            System.out.print(c+" ");
//            a=b;
//            b=c;
//        }

//        firstRepeating
//        String s="manishshah";
//        for(int i=0;i<s.length();i++){
//            boolean b=false;
//            for(int j=0;j<s.length();j++){
//                if(i!=j && s.charAt(i)==s.charAt(j)){
//                   b=true;
//                    break;
//                }
//            }
//            if(b){
//                System.out.println(s.charAt(i));
//                break;
//            }
//        }

//prime number
//        int count=0;
//        Scanner s4=new Scanner(System.in);
//        System.out.print("Enter a number to check prime number or not:");
//        int a=s4.nextInt();
//        for(int i=1;i<=a;i++){
//            if(a%i==0){
//                count++;
//            }
//        }
//        if(count==2){
//            System.out.println("the enter number is prime");
//        }
//        else{
//            System.out.println("the enter number is not prime ");
//        }


//prime 1-100
//        for(int i=1;i<100;i++) {
//            int count=0;
//            for (int j = 1; j <= i; j++) {
//                if (i % j == 0) {
//                    count++;
//                }
//            }
//            if (count == 2) {
//                System.out.println(i);
//            }
//        }

//        binary search
        int []a={2,4,6,8,9,10};
        int low=0;
        int high=a.length-1;
        Scanner sc=new Scanner(System.in);
        System.out.print("enter search element:");
        int search=sc.nextInt();

        while(low<=high){
            int mid=low+high;
            if(a[mid]==search){
                System.out.println("the search element is in index : "+mid);
                break;
            }
            else if(a[mid]<search){
                low=mid+1;
            }
            else{
                high=mid-1;
            }
        }
        if(low>high){
            System.out.println("element not found");
        }

//        swap
//        int a=9;
//        int b=8;
//        int c=a+b;
//        a=c-a;
//        b=c-b;
//        System.out.println("the swap value of a is :" +a+" "+"the value of b is: "+ b);
//        int a=9;
//        int b=8;
//        int temp=a;
//        a=b;
//        b=temp;
//        System.out.println("the swap value of a is :" +a+" "+"the value of b is: "+ b);

//bubble sort
//        int [] a={2,5,4,6,7,1,3};
//        for(int i=0;i<a.length;i++){
//            for(int j=1;j<a.length-i;j++){
//                if(a[j-1]>a[j]){
//                    int temp=a[j];
//                    a[j]=a[j-1];
//                    a[j-1]=temp;
//                }
//            }
//        }
//        for(int i=0;i<a.length;i++) {
//            System.out.println(a[i]);
//        }

//        rotation
//int []a={2,4,1,6,9,70,0};
String s="manishshah";
char[] c=s.toCharArray();
//        System.out.println(Character.isUpperCase(c[0]));
//        System.out.println(c[0]=Character.toUpperCase(c[0]));
//        System.out.println(Character.isUpperCase(c[0]));
//Arrays.sort(a);
//int k=2;
//        rotate(a,k);
//        Print(a);

//        even
//        for(int i=1;i<=100;i++){
//            if(i%2==0){
//                System.out.println("even: "+i);
//            }
//            else{
//                System.out.println("odd: "+i);
//            }
//        }


}
}