package com.company;

public class P11_MinimumNo {
    public static void main(String[] args) {
        int[] a={2,8,5,2,9,4,3,1};
        int min=a[0];
        int secmin=0;
        for(int i=0;i<a.length;i++){
            if(a[i]<min){
                secmin=min;
                min=a[i];
            }
            else if(min!=a[i]){
                if(a[i]<secmin) {
                    secmin = a[i];
                }
            }
        }
        System.out.println(min);
        System.out.println(secmin);
    }
}
